package server

import (
	"bytes"
	"crypto/hmac"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"log"
	"net/http"
	"os"
	"sync"
	"time"
)

// Webhook represents a registered webhook endpoint.
type Webhook struct {
	URL    string   `json:"url"`
	Events []string `json:"events"` // e.g. ["build_complete", "index_deleted"]
	Secret string   `json:"secret,omitempty"`
}

// redacted returns a copy with the signing secret masked.
func (wh Webhook) redacted() Webhook {
	if wh.Secret != "" {
		wh.Secret = "********"
	}
	return wh
}

// webhookStore manages registered webhooks (in-memory).
type webhookStore struct {
	mu       sync.RWMutex
	webhooks []Webhook
}

var globalWebhooks = &webhookStore{}

// webhookRegisterRequest is the request body for POST /api/webhooks.
type webhookRegisterRequest struct {
	URL    string   `json:"url"`
	Events []string `json:"events"`
	Secret string   `json:"secret,omitempty"`
}

// handleListWebhooks returns all registered webhooks.
func (s *Server) handleListWebhooks(w http.ResponseWriter, r *http.Request) {
	globalWebhooks.mu.RLock()
	defer globalWebhooks.mu.RUnlock()

	// Never echo secrets back to clients.
	hooks := make([]Webhook, len(globalWebhooks.webhooks))
	for i, wh := range globalWebhooks.webhooks {
		hooks[i] = wh.redacted()
	}
	writeJSON(w, http.StatusOK, map[string]any{
		"webhooks": hooks,
		"count":    len(hooks),
	})
}

// handleRegisterWebhook registers a new webhook.
func (s *Server) handleRegisterWebhook(w http.ResponseWriter, r *http.Request) {
	var req webhookRegisterRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeError(w, http.StatusBadRequest, "invalid request body: "+err.Error())
		return
	}

	if req.URL == "" {
		writeError(w, http.StatusBadRequest, "url is required")
		return
	}
	if len(req.Events) == 0 {
		writeError(w, http.StatusBadRequest, "events is required (e.g. [\"build_complete\", \"index_deleted\"])")
		return
	}
	if err := validateWebhookURL(req.URL); err != nil {
		writeError(w, http.StatusBadRequest, err.Error())
		return
	}

	wh := Webhook(req)

	globalWebhooks.mu.Lock()
	globalWebhooks.webhooks = append(globalWebhooks.webhooks, wh)
	globalWebhooks.mu.Unlock()

	writeJSON(w, http.StatusCreated, map[string]any{
		"status":  "registered",
		"webhook": wh.redacted(),
	})
}

// handleDeleteWebhook removes a webhook by URL.
func (s *Server) handleDeleteWebhook(w http.ResponseWriter, r *http.Request) {
	var req struct {
		URL string `json:"url"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeError(w, http.StatusBadRequest, "invalid request body: "+err.Error())
		return
	}

	if req.URL == "" {
		writeError(w, http.StatusBadRequest, "url is required")
		return
	}

	globalWebhooks.mu.Lock()
	found := false
	filtered := globalWebhooks.webhooks[:0]
	for _, wh := range globalWebhooks.webhooks {
		if wh.URL == req.URL {
			found = true
			continue
		}
		filtered = append(filtered, wh)
	}
	globalWebhooks.webhooks = filtered
	globalWebhooks.mu.Unlock()

	if !found {
		writeError(w, http.StatusNotFound, "webhook not found for url: "+req.URL)
		return
	}

	writeJSON(w, http.StatusOK, map[string]any{
		"status": "deleted",
		"url":    req.URL,
	})
}

// notifyWebhooks sends an event payload to all registered webhooks matching the event type.
// It runs asynchronously and does not block the caller.
func notifyWebhooks(event string, payload map[string]any) {
	globalWebhooks.mu.RLock()
	var targets []Webhook
	for _, wh := range globalWebhooks.webhooks {
		for _, e := range wh.Events {
			if e == event || e == "*" {
				targets = append(targets, wh)
				break
			}
		}
	}
	globalWebhooks.mu.RUnlock()

	if len(targets) == 0 {
		return
	}

	payload["event"] = event
	payload["timestamp"] = time.Now().UTC().Format(time.RFC3339)
	body, err := json.Marshal(payload)
	if err != nil {
		return
	}

	for _, wh := range targets {
		serverMetrics.RecordWebhook()
		go fireWebhookHTTP(wh.URL, wh.Secret, body)
	}
}

// fireWebhookHTTP sends a POST request to the webhook URL with the JSON payload.
// If a secret is configured, it adds an X-Gleann-Signature header (HMAC-SHA256).
func fireWebhookHTTP(url, secret string, body []byte) {
	req, err := http.NewRequest(http.MethodPost, url, bytes.NewReader(body))
	if err != nil {
		log.Printf("webhook: failed to create request for %s: %v", url, err)
		return
	}
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("User-Agent", "gleann-webhook/1.0")

	if secret != "" {
		mac := hmac.New(sha256.New, []byte(secret))
		mac.Write(body)
		sig := hex.EncodeToString(mac.Sum(nil))
		req.Header.Set("X-Gleann-Signature", "sha256="+sig)
	}

	resp, err := webhookHTTPClient.Do(req)
	if err != nil {
		log.Printf("webhook: failed to deliver to %s: %v", url, err)
		return
	}
	resp.Body.Close()

	if resp.StatusCode >= 300 && resp.StatusCode < 400 {
		log.Printf("webhook: %s returned redirect %d (redirects are not followed)", url, resp.StatusCode)
	} else if resp.StatusCode >= 400 {
		log.Printf("webhook: %s returned status %d", url, resp.StatusCode)
	}
}

// webhookAllowPrivate reports whether webhooks may target private/loopback
// addresses (GLEANN_WEBHOOK_ALLOW_PRIVATE=1). Read at fire time.
func webhookAllowPrivate() bool {
	return os.Getenv("GLEANN_WEBHOOK_ALLOW_PRIVATE") == "1"
}

// webhookHTTPClient delivers webhooks. Redirects are never followed (a
// public endpoint could otherwise bounce the POST to an internal service),
// and the resolved address is re-checked at dial time so a hostname that
// passed validateWebhookURL cannot later be rebound to a private IP.
var webhookHTTPClient = &http.Client{
	Timeout:   10 * time.Second,
	Transport: newGuardedTransport(webhookAllowPrivate, 10*time.Second),
	CheckRedirect: func(*http.Request, []*http.Request) error {
		return http.ErrUseLastResponse
	},
}
