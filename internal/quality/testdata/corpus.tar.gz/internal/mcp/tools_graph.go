//go:build treesitter

package mcp

import (
	"context"
	"encoding/json"
	"fmt"
	"path/filepath"
	"sort"
	"strings"
	"sync"

	mcpsdk "github.com/mark3labs/mcp-go/mcp"
	"github.com/tevfik/gleann/internal/graph/community"
	kgraph "github.com/tevfik/gleann/internal/graph/kuzu"
	"github.com/tevfik/gleann/pkg/gleann"
)

// ── Graph DB pool for community detection ────────────────────────────────

// graphPool caches open KuzuDB handles for community detection queries.
type graphPool struct {
	mu  sync.Mutex
	dbs map[string]*kgraph.DB
	dir string
}

func newGraphPool(indexDir string) *graphPool {
	return &graphPool{
		dbs: make(map[string]*kgraph.DB),
		dir: indexDir,
	}
}

func (p *graphPool) get(name string) (*kgraph.DB, error) {
	p.mu.Lock()
	defer p.mu.Unlock()
	if db, ok := p.dbs[name]; ok {
		return db, nil
	}
	if err := gleann.ValidateName(name); err != nil {
		return nil, err
	}
	dbPath := filepath.Join(p.dir, name+"_graph")
	db, err := kgraph.Open(dbPath)
	if err != nil {
		return nil, err
	}
	p.dbs[name] = db
	return db, nil
}

func (p *graphPool) close(name string) {
	p.mu.Lock()
	defer p.mu.Unlock()
	if db, ok := p.dbs[name]; ok {
		db.Close()
		delete(p.dbs, name)
	}
}

func (p *graphPool) closeAll() {
	p.mu.Lock()
	defer p.mu.Unlock()
	for _, db := range p.dbs {
		db.Close()
	}
	p.dbs = make(map[string]*kgraph.DB)
}

// initGraphPool initializes the graph pool for community detection tools.
// Called during NewServer if treesitter is available.
func (s *Server) initGraphPool() {
	s.gPool = newGraphPool(s.config.IndexDir)
}

// closeGraphPool cleans up the graph pool.
func (s *Server) closeGraphPool() {
	if s.gPool != nil {
		s.gPool.closeAll()
	}
}

// evictGraph closes and evicts the graph handle for a specific index.
func (s *Server) evictGraph(name string) {
	if s.gPool != nil {
		s.gPool.close(name)
	}
}

// registerGraphTools registers community detection, risk analysis, and
// repo map tools. Only available with treesitter build tag.
func (s *Server) registerGraphTools() {
	s.addTool(s.buildCommunitiesTool(), s.handleCommunities)
	s.addTool(s.buildRiskAnalysisTool(), s.handleRiskAnalysis)
	s.addTool(s.buildRepoMapTool(), s.handleRepoMap)
	s.addTool(s.buildNavigateSymbolTool(), s.handleNavigateSymbol)
}

// ── Communities Tool ─────────────────────────────────────────────────────

func (s *Server) buildCommunitiesTool() mcpsdk.Tool {
	return mcpsdk.Tool{
		Name:        "gleann_communities",
		Description: "Run Louvain community detection on the code graph. Returns communities, god nodes (high-degree hubs), surprising cross-community edges, and modularity score.",
		InputSchema: mcpsdk.ToolInputSchema{
			Type: "object",
			Properties: map[string]interface{}{
				"index": map[string]interface{}{
					"type":        "string",
					"description": "Name of the index to analyze",
				},
			},
			Required: []string{"index"},
		},
	}
}

func (s *Server) handleCommunities(ctx context.Context, request mcpsdk.CallToolRequest) (*mcpsdk.CallToolResult, error) {
	args, ok := request.Params.Arguments.(map[string]interface{})
	if !ok {
		return mcpsdk.NewToolResultError("invalid arguments format"), nil
	}

	indexName, _ := args["index"].(string)
	if indexName == "" {
		return mcpsdk.NewToolResultError("index is required"), nil
	}

	db, err := s.gPool.get(indexName)
	if err != nil {
		return mcpsdk.NewToolResultError(fmt.Sprintf("Error opening graph %q: %v", indexName, err)), nil
	}

	result, err := community.FromKuzu(db, 5, 20)
	if err != nil {
		return mcpsdk.NewToolResultError(fmt.Sprintf("Community detection failed: %v", err)), nil
	}

	data, err := json.Marshal(result)
	if err != nil {
		return mcpsdk.NewToolResultError(fmt.Sprintf("JSON encoding failed: %v", err)), nil
	}

	var sb strings.Builder
	sb.WriteString(fmt.Sprintf("Community Detection — %s\n", indexName))
	sb.WriteString(fmt.Sprintf("Nodes: %d | Edges: %d | Communities: %d | Modularity: %.4f\n\n",
		result.NodeCount, result.EdgeCount, len(result.Communities), result.Modularity))

	for _, c := range result.Communities {
		sb.WriteString(fmt.Sprintf("Community %d: %s (%d nodes, cohesion=%.3f)\n",
			c.ID, c.Label, c.NodeCount, c.Cohesion))
	}

	if len(result.GodNodes) > 0 {
		sb.WriteString("\nGod Nodes (high-degree hubs):\n")
		for _, g := range result.GodNodes {
			sb.WriteString(fmt.Sprintf("  [%s] %s (in=%d, out=%d)\n", g.Kind, g.Name, g.InDeg, g.OutDeg))
		}
	}

	if len(result.SurprisingEdges) > 0 {
		sb.WriteString("\nSurprising edges:\n")
		for _, e := range result.SurprisingEdges {
			sb.WriteString(fmt.Sprintf("  %s → %s (community %d → %d)\n",
				e.From, e.To, e.FromCommunity, e.ToCommunity))
		}
	}

	sb.WriteString("\n--- Raw JSON ---\n")
	sb.Write(data)

	return mcpsdk.NewToolResultText(sb.String()), nil
}

// ── Risk Analysis Tool ───────────────────────────────────────────────────

func (s *Server) buildRiskAnalysisTool() mcpsdk.Tool {
	return mcpsdk.Tool{
		Name:        "gleann_risk_analysis",
		Description: "Compute change risk scores for symbols in the code graph using PageRank centrality, coupling, and blast radius metrics. Returns ranked symbols with risk levels (critical/high/medium/low).",
		InputSchema: mcpsdk.ToolInputSchema{
			Type: "object",
			Properties: map[string]interface{}{
				"index": map[string]interface{}{
					"type":        "string",
					"description": "Name of the index to analyze",
				},
				"top": map[string]interface{}{
					"type":        "integer",
					"description": "Number of top risk symbols to return (default 20)",
				},
				"by_file": map[string]interface{}{
					"type":        "boolean",
					"description": "If true, aggregate risk scores by file instead of individual symbols",
				},
			},
			Required: []string{"index"},
		},
	}
}

func (s *Server) handleRiskAnalysis(ctx context.Context, request mcpsdk.CallToolRequest) (*mcpsdk.CallToolResult, error) {
	args, ok := request.Params.Arguments.(map[string]interface{})
	if !ok {
		return mcpsdk.NewToolResultError("invalid arguments format"), nil
	}

	indexName, _ := args["index"].(string)
	if indexName == "" {
		indexName = s.resolveIndexName()
		if indexName == "" {
			return mcpsdk.NewToolResultError("index is required"), nil
		}
	}

	topN := 20
	if t, ok := args["top"].(float64); ok && t > 0 {
		topN = int(t)
	}

	byFile, _ := args["by_file"].(bool)

	db, err := s.gPool.get(indexName)
	if err != nil {
		return mcpsdk.NewToolResultError(fmt.Sprintf("Error opening graph %q: %v", indexName, err)), nil
	}

	// Check graph size to choose between in-memory PageRank and fast Cypher aggregation
	var totalSymbols int64
	if cntRes, err := db.Conn().Query(`MATCH (s:Symbol) RETURN count(s) AS c`); err == nil {
		if cntRes.HasNext() {
			row, _ := cntRes.Next()
			m, _ := row.GetAsMap()
			if c, ok := m["c"].(int64); ok {
				totalSymbols = c
			}
		}
		cntRes.Close()
	}

	if totalSymbols == 0 {
		return mcpsdk.NewToolResultText("No nodes in graph. Build index with --graph flag."), nil
	}

	var sb strings.Builder

	if totalSymbols > 2000 {
		// Fast path for large graphs: aggregate hub symbols directly in KùzuDB in milliseconds
		if byFile {
			query := fmt.Sprintf(`
				MATCH (caller:Symbol)-[:CALLS]->(s:Symbol)
				WHERE s.file IS NOT NULL AND s.file <> ''
				RETURN s.file AS file, s.name AS top_symbol, count(caller) AS callers
				ORDER BY callers DESC
				LIMIT %d
			`, topN)
			res, err := db.Conn().Query(query)
			if err != nil {
				return mcpsdk.NewToolResultError(fmt.Sprintf("Query error: %v", err)), nil
			}
			defer res.Close()
			sb.WriteString(fmt.Sprintf("File Risk Analysis — %s (top %d)\n\n", indexName, topN))
			sb.WriteString(fmt.Sprintf("%-50s %-10s %-8s %s\n", "FILE", "RISK", "SCORE", "TOP SYMBOL"))
			sb.WriteString(strings.Repeat("─", 90) + "\n")
			for res.HasNext() {
				row, _ := res.Next()
				m, _ := row.GetAsMap()
				callers := m["callers"].(int64)
				risk := "LOW"
				if callers >= 50 {
					risk = "CRITICAL"
				} else if callers >= 20 {
					risk = "HIGH"
				} else if callers >= 5 {
					risk = "MEDIUM"
				}
				score := float64(callers) / 100.0
				sb.WriteString(fmt.Sprintf("%-50s %-10s %.4f   %s\n",
					truncPath(fmt.Sprint(m["file"]), 48), risk, score, fmt.Sprint(m["top_symbol"])))
			}
		} else {
			query := fmt.Sprintf(`
				MATCH (caller:Symbol)-[:CALLS]->(s:Symbol)
				WHERE s.file IS NOT NULL AND s.file <> '' AND s.kind <> 'macro'
				RETURN s.name AS name, s.kind AS kind, s.file AS file, count(caller) AS in_degree
				ORDER BY in_degree DESC
				LIMIT %d
			`, topN)
			res, err := db.Conn().Query(query)
			if err != nil {
				return mcpsdk.NewToolResultError(fmt.Sprintf("Query error: %v", err)), nil
			}
			defer res.Close()
			sb.WriteString(fmt.Sprintf("Symbol Risk Analysis — %s (top %d)\n\n", indexName, topN))
			sb.WriteString(fmt.Sprintf("%-40s %-10s %-10s %-6s %-6s %-6s %s\n",
				"SYMBOL", "KIND", "RISK", "IN", "OUT", "BLAST", "SCORE"))
			sb.WriteString(strings.Repeat("─", 100) + "\n")
			for res.HasNext() {
				row, _ := res.Next()
				m, _ := row.GetAsMap()
				inDeg := m["in_degree"].(int64)
				risk := "LOW"
				if inDeg >= 50 {
					risk = "CRITICAL"
				} else if inDeg >= 20 {
					risk = "HIGH"
				} else if inDeg >= 5 {
					risk = "MEDIUM"
				}
				score := float64(inDeg) / 100.0
				sb.WriteString(fmt.Sprintf("%-40s %-10s %-10s %-6d %-6d %-6d %.4f\n",
					truncPath(fmt.Sprint(m["name"]), 38), fmt.Sprint(m["kind"]), risk,
					inDeg, 0, inDeg, score))
			}
		}
		return mcpsdk.NewToolResultText(sb.String()), nil
	}

	// Small graph: full in-memory community graph analysis
	g := community.NewGraph()
	loadGraphFromKuzu(db, g)
	nodes, edges := g.ExportForAnalysis()

	if len(nodes) == 0 {
		return mcpsdk.NewToolResultText("No nodes in graph. Build index with --graph flag."), nil
	}

	cfg := community.DefaultRiskConfig()
	allScores := community.ComputeRiskScores(nodes, edges, cfg)

	if byFile {
		fileSummary := community.FileRiskSummary(allScores)
		if topN > len(fileSummary) {
			topN = len(fileSummary)
		}
		sb.WriteString(fmt.Sprintf("File Risk Analysis — %s (top %d)\n\n", indexName, topN))
		sb.WriteString(fmt.Sprintf("%-50s %-10s %-8s %s\n", "FILE", "RISK", "SCORE", "TOP SYMBOL"))
		sb.WriteString(strings.Repeat("─", 90) + "\n")
		for _, rs := range fileSummary[:topN] {
			sb.WriteString(fmt.Sprintf("%-50s %-10s %.4f   %s\n",
				truncPath(rs.File, 48), rs.RiskLevel, rs.Score, rs.Name))
		}
	} else {
		top := community.TopRisks(allScores, topN)
		sb.WriteString(fmt.Sprintf("Symbol Risk Analysis — %s (top %d)\n\n", indexName, topN))
		sb.WriteString(fmt.Sprintf("%-40s %-10s %-10s %-6s %-6s %-6s %s\n",
			"SYMBOL", "KIND", "RISK", "IN", "OUT", "BLAST", "SCORE"))
		sb.WriteString(strings.Repeat("─", 100) + "\n")
		for _, rs := range top {
			sb.WriteString(fmt.Sprintf("%-40s %-10s %-10s %-6d %-6d %-6d %.4f\n",
				truncPath(rs.Name, 38), rs.Kind, rs.RiskLevel,
				rs.InDegree, rs.OutDegree, rs.BlastRadiusSize, rs.Score))
		}
	}

	return mcpsdk.NewToolResultText(sb.String()), nil
}

// ── Repo Map Tool ────────────────────────────────────────────────────────

func (s *Server) buildRepoMapTool() mcpsdk.Tool {
	return mcpsdk.Tool{
		Name:        "gleann_repo_map",
		Description: "Generate a compact text map of the repository ranked by symbol importance (PageRank). Ideal for injecting into LLM context to provide codebase awareness.",
		InputSchema: mcpsdk.ToolInputSchema{
			Type: "object",
			Properties: map[string]interface{}{
				"index": map[string]interface{}{
					"type":        "string",
					"description": "Name of the index to generate map for",
				},
				"top_k": map[string]interface{}{
					"type":        "integer",
					"description": "Number of top symbols to include (default 30)",
				},
				"max_tokens": map[string]interface{}{
					"type":        "integer",
					"description": "Approximate token budget for the map (default 2000)",
				},
			},
			Required: []string{},
		},
	}
}

func (s *Server) handleRepoMap(ctx context.Context, request mcpsdk.CallToolRequest) (*mcpsdk.CallToolResult, error) {
	args, ok := request.Params.Arguments.(map[string]interface{})
	if !ok {
		return mcpsdk.NewToolResultError("invalid arguments format"), nil
	}

	indexName, _ := args["index"].(string)
	if indexName == "" {
		indexName = s.resolveIndexName()
		if indexName == "" {
			return mcpsdk.NewToolResultError("index is required"), nil
		}
	}

	topK := 30
	if t, ok := args["top_k"].(float64); ok && t > 0 {
		topK = int(t)
	}
	maxTokens := 2000
	if mt, ok := args["max_tokens"].(float64); ok && mt > 0 {
		maxTokens = int(mt)
	}

	db, err := s.gPool.get(indexName)
	if err != nil {
		return mcpsdk.NewToolResultError(fmt.Sprintf("Error opening graph %q: %v", indexName, err)), nil
	}

	candidateLimit := topK * 10
	if candidateLimit < 100 {
		candidateLimit = 100
	}

	type repoMapItem struct {
		FQN   string
		Name  string
		Kind  string
		File  string
		Score float64
	}
	var cleanItems []repoMapItem
	var fallbackItems []repoMapItem

	// Primary path: compute true PageRank centrality across the entire AST code graph
	if g, err := community.LoadGraphFromKuzu(db); err == nil && g.NodeCount() > 0 {
		nodes, edges := g.ExportForAnalysis()
		ranks := community.PageRank(nodes, edges, 0.85, 30)

		for _, n := range nodes {
			if n.Kind == "file" || n.File == "" || n.Kind == "macro" {
				continue
			}
			score := ranks[n.ID]
			item := repoMapItem{
				FQN:   n.ID,
				Name:  n.Name,
				Kind:  n.Kind,
				File:  n.File,
				Score: score,
			}
			if isNoisePath(item.File) || isNoiseSymbol(item.Name, item.Kind) {
				fallbackItems = append(fallbackItems, item)
			} else {
				cleanItems = append(cleanItems, item)
			}
		}

		sort.Slice(cleanItems, func(i, j int) bool {
			return cleanItems[i].Score > cleanItems[j].Score
		})
		sort.Slice(fallbackItems, func(i, j int) bool {
			return fallbackItems[i].Score > fallbackItems[j].Score
		})
	}

	// Secondary path: if no graph/edges loaded, fallback to Cypher caller count query
	if len(cleanItems) == 0 && len(fallbackItems) == 0 {
		candidateLimit := topK * 10
		if candidateLimit < 100 {
			candidateLimit = 100
		}
		query := fmt.Sprintf(`
			MATCH (caller:Symbol)-[:CALLS]->(s:Symbol)
			WHERE s.file IS NOT NULL AND s.file <> '' AND s.kind <> 'macro'
			RETURN s.fqn AS fqn, s.name AS name, s.kind AS kind, s.file AS file, count(caller) AS callers
			ORDER BY callers DESC
			LIMIT %d
		`, candidateLimit)

		res, err := db.Conn().Query(query)
		if err == nil {
			for res.HasNext() {
				row, err := res.Next()
				if err != nil {
					break
				}
				m, _ := row.GetAsMap()
				score := 0.0
				if sc, ok := m["callers"].(int64); ok {
					score = float64(sc)
				}
				item := repoMapItem{
					FQN:   fmt.Sprint(m["fqn"]),
					Name:  fmt.Sprint(m["name"]),
					Kind:  fmt.Sprint(m["kind"]),
					File:  fmt.Sprint(m["file"]),
					Score: score,
				}
				if isNoisePath(item.File) || isNoiseSymbol(item.Name, item.Kind) {
					fallbackItems = append(fallbackItems, item)
				} else {
					cleanItems = append(cleanItems, item)
				}
			}
			res.Close()
		}
	}

	var items []repoMapItem
	if len(cleanItems) >= topK {
		items = cleanItems[:topK]
	} else {
		items = append(items, cleanItems...)
		needed := topK - len(items)
		if needed > len(fallbackItems) {
			needed = len(fallbackItems)
		}
		items = append(items, fallbackItems[:needed]...)
	}

	// Fallback if no CALLS edges exist in the graph (e.g. declarations only)
	if len(items) == 0 {
		fallbackQuery := fmt.Sprintf(`
			MATCH (s:Symbol)
			WHERE s.file IS NOT NULL AND s.file <> '' AND s.kind <> 'macro'
			RETURN s.fqn AS fqn, s.name AS name, s.kind AS kind, s.file AS file, 1 AS callers
			LIMIT %d
		`, candidateLimit)
		resFallback, err := db.Conn().Query(fallbackQuery)
		if err == nil {
			for resFallback.HasNext() {
				row, err := resFallback.Next()
				if err != nil {
					break
				}
				m, _ := row.GetAsMap()
				item := repoMapItem{
					FQN:   fmt.Sprint(m["fqn"]),
					Name:  fmt.Sprint(m["name"]),
					Kind:  fmt.Sprint(m["kind"]),
					File:  fmt.Sprint(m["file"]),
					Score: 1.0,
				}
				if isNoisePath(item.File) || isNoiseSymbol(item.Name, item.Kind) {
					fallbackItems = append(fallbackItems, item)
				} else {
					cleanItems = append(cleanItems, item)
				}
			}
			resFallback.Close()

			if len(cleanItems) >= topK {
				items = cleanItems[:topK]
			} else {
				items = append(items, cleanItems...)
				needed := topK - len(items)
				if needed > len(fallbackItems) {
					needed = len(fallbackItems)
				}
				items = append(items, fallbackItems[:needed]...)
			}
		}
	}

	if len(items) == 0 {
		return mcpsdk.NewToolResultText("No nodes in graph. Build index with --graph flag."), nil
	}

	// Group by file
	type entry struct {
		id    string
		kind  string
		score float64
	}
	fileGroups := make(map[string][]entry)
	for _, it := range items {
		f := it.File
		if f == "" {
			f = "(unknown)"
		}
		name := it.Name
		if name == "" {
			name = it.FQN
		}
		fileGroups[f] = append(fileGroups[f], entry{id: name, kind: it.Kind, score: it.Score})
	}

	// Sort files by total score
	type fileEntry struct {
		file    string
		total   float64
		entries []entry
	}
	var files []fileEntry
	for f, entries := range fileGroups {
		total := 0.0
		for _, e := range entries {
			total += e.score
		}
		files = append(files, fileEntry{file: f, total: total, entries: entries})
	}
	sort.Slice(files, func(i, j int) bool {
		return files[i].total > files[j].total
	})

	var sb strings.Builder
	sb.WriteString(fmt.Sprintf("## Repository Map — %s (by importance)\n\n", indexName))
	tokenEstimate := 10
	for _, fe := range files {
		line := fmt.Sprintf("### %s\n", fe.file)
		tokenEstimate += len(line) / 4
		if maxTokens > 0 && tokenEstimate > maxTokens {
			break
		}
		sb.WriteString(line)

		for _, e := range fe.entries {
			sym := fmt.Sprintf("- %s `%s`\n", e.kind, e.id)
			tokenEstimate += len(sym) / 4
			if maxTokens > 0 && tokenEstimate > maxTokens {
				break
			}
			sb.WriteString(sym)
		}
		sb.WriteString("\n")
	}

	return mcpsdk.NewToolResultText(sb.String()), nil
}

// ── Helpers ──────────────────────────────────────────────────────────────

// loadGraphFromKuzu populates a community.Graph from KuzuDB.
func loadGraphFromKuzu(db *kgraph.DB, g *community.Graph) {
	res, err := db.Conn().Query(`MATCH (s:Symbol) RETURN s.fqn AS fqn, s.name AS name, s.kind AS kind, s.file AS file`)
	if err == nil {
		for res.HasNext() {
			row, _ := res.Next()
			m, _ := row.GetAsMap()
			g.AddNode(community.Node{
				ID:   fmt.Sprint(m["fqn"]),
				Name: fmt.Sprint(m["name"]),
				Kind: fmt.Sprint(m["kind"]),
				File: fmt.Sprint(m["file"]),
			})
		}
		res.Close()
	}
	res2, err := db.Conn().Query(`MATCH (a:Symbol)-[:CALLS]->(b:Symbol) RETURN a.fqn AS from, b.fqn AS to`)
	if err == nil {
		for res2.HasNext() {
			row, _ := res2.Next()
			m, _ := row.GetAsMap()
			g.AddEdge(fmt.Sprint(m["from"]), fmt.Sprint(m["to"]), 1.0)
		}
		res2.Close()
	}
}

// truncPath truncates a string for display in tabular output.
func truncPath(s string, maxLen int) string {
	if len(s) <= maxLen {
		return s
	}
	return s[:maxLen-3] + "..."
}

// ── Navigate Symbol Tool ─────────────────────────────────────────────────

func (s *Server) buildNavigateSymbolTool() mcpsdk.Tool {
	return mcpsdk.Tool{
		Name:        "gleann_navigate_symbol",
		Description: "Navigate to a symbol in the code graph. Returns the symbol's definition context, callers, and callees without loading full files. Ideal for pointer-based code exploration that saves context window budget.",
		InputSchema: mcpsdk.ToolInputSchema{
			Type: "object",
			Properties: map[string]interface{}{
				"index": map[string]interface{}{
					"type":        "string",
					"description": "Name of the index to search",
				},
				"symbol": map[string]interface{}{
					"type":        "string",
					"description": "Symbol name or pattern to navigate to (e.g. 'handleRequest', 'Server.Start')",
				},
				"depth": map[string]interface{}{
					"type":        "integer",
					"description": "How many levels of callers/callees to return (default 1, max 3)",
				},
			},
			Required: []string{"index", "symbol"},
		},
	}
}

func (s *Server) handleNavigateSymbol(ctx context.Context, request mcpsdk.CallToolRequest) (*mcpsdk.CallToolResult, error) {
	args, ok := request.Params.Arguments.(map[string]interface{})
	if !ok {
		return mcpsdk.NewToolResultError("invalid arguments format"), nil
	}

	indexName, _ := args["index"].(string)
	if indexName == "" {
		return mcpsdk.NewToolResultError("index is required"), nil
	}
	symbol, _ := args["symbol"].(string)
	if symbol == "" {
		return mcpsdk.NewToolResultError("symbol is required"), nil
	}

	depth := 1
	if d, ok := args["depth"].(float64); ok && d >= 1 && d <= 3 {
		depth = int(d)
	}

	db, err := s.gPool.get(indexName)
	if err != nil {
		return mcpsdk.NewToolResultError(fmt.Sprintf("Error opening graph %q: %v", indexName, err)), nil
	}

	// Find matching symbols.
	matches, err := db.SymbolSearch(symbol)
	if err != nil {
		return mcpsdk.NewToolResultError(fmt.Sprintf("Symbol search failed: %v", err)), nil
	}
	if len(matches) == 0 {
		return mcpsdk.NewToolResultText(fmt.Sprintf("No symbols matching %q found in graph.", symbol)), nil
	}

	// Limit to top 5 matches.
	if len(matches) > 5 {
		matches = matches[:5]
	}

	var sb strings.Builder
	sb.WriteString(fmt.Sprintf("Symbol Navigation — %q in %s\n\n", symbol, indexName))

	for i, m := range matches {
		sb.WriteString(fmt.Sprintf("── %d. %s (%s)\n", i+1, m.FQN, m.Kind))

		// Get callers.
		callers, err := db.Callers(m.FQN)
		if err == nil && len(callers) > 0 {
			var prodCallers, testCallers []gleann.Callee
			for _, c := range callers {
				if c.IsTest {
					testCallers = append(testCallers, c)
				} else {
					prodCallers = append(prodCallers, c)
				}
			}

			sb.WriteString("  Callers:\n")
			limit := len(prodCallers)
			if limit > 10 {
				limit = 10
			}
			for _, c := range prodCallers[:limit] {
				loc := ""
				if c.File != "" {
					if c.Line > 0 {
						loc = fmt.Sprintf(" [%s:%d]", c.File, c.Line)
					} else {
						loc = fmt.Sprintf(" [%s]", c.File)
					}
				}
				sb.WriteString(fmt.Sprintf("    ← %s (%s)%s\n", c.FQN, c.Kind, loc))
			}
			if len(prodCallers) > 10 {
				sb.WriteString(fmt.Sprintf("    ... and %d more production callers\n", len(prodCallers)-10))
			}
			if len(testCallers) > 0 {
				sb.WriteString(fmt.Sprintf("    [+ %d test caller(s)]\n", len(testCallers)))
			}
			if len(prodCallers) == 0 && len(testCallers) == 0 {
				sb.WriteString("    none\n")
			}
		} else {
			sb.WriteString("  Callers: none\n")
		}

		// Get callees.
		callees, err := db.Callees(m.FQN)
		if err == nil && len(callees) > 0 {
			sb.WriteString("  Callees:\n")
			limit := len(callees)
			if limit > 10 {
				limit = 10
			}
			for _, c := range callees[:limit] {
				loc := ""
				if c.File != "" {
					if c.Line > 0 {
						loc = fmt.Sprintf(" [%s:%d]", c.File, c.Line)
					} else {
						loc = fmt.Sprintf(" [%s]", c.File)
					}
				}
				sb.WriteString(fmt.Sprintf("    → %s (%s)%s\n", c.FQN, c.Kind, loc))
			}
			if len(callees) > 10 {
				sb.WriteString(fmt.Sprintf("    ... and %d more\n", len(callees)-10))
			}
		} else {
			sb.WriteString("  Callees: none\n")
		}

		// For depth > 1, recurse on callees.
		if depth > 1 && len(callees) > 0 {
			sb.WriteString("  2nd-level callees:\n")
			seen := make(map[string]bool)
			var secondLevel []gleann.Callee
			count := 0
			for _, c := range callees {
				if count >= 20 {
					break
				}
				sub, err := db.Callees(c.FQN)
				if err == nil {
					for _, sc := range sub {
						if !seen[sc.FQN] {
							seen[sc.FQN] = true
							secondLevel = append(secondLevel, sc)
							sb.WriteString(fmt.Sprintf("    %s → %s (%s)\n", c.FQN, sc.FQN, sc.Kind))
							count++
							if count >= 20 {
								break
							}
						}
					}
				}
			}

			// If depth >= 3, recurse to 3rd-level callees
			if depth >= 3 && len(secondLevel) > 0 {
				sb.WriteString("  3rd-level callees:\n")
				seen3 := make(map[string]bool)
				count3 := 0
				for _, sc := range secondLevel {
					if count3 >= 20 {
						break
					}
					sub3, err := db.Callees(sc.FQN)
					if err == nil {
						for _, ssc := range sub3 {
							if !seen[ssc.FQN] && !seen3[ssc.FQN] {
								seen3[ssc.FQN] = true
								sb.WriteString(fmt.Sprintf("    %s → %s (%s)\n", sc.FQN, ssc.FQN, ssc.Kind))
								count3++
								if count3 >= 20 {
									break
								}
							}
						}
					}
				}
			}
		}

		sb.WriteString("\n")
	}

	return mcpsdk.NewToolResultText(sb.String()), nil
}
