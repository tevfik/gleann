package tui

import (
	"bytes"
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"reflect"
	"runtime"
	"strings"
)

// DefaultIndexDir returns the platform-appropriate default index directory.
//   - Linux/Mac: /home/user/.gleann/indexes
//   - Windows:   C:\Users\user\.gleann\indexes
func DefaultIndexDir() string {
	home, _ := os.UserHomeDir()
	return filepath.Join(home, ".gleann", "indexes")
}

// DefaultModelsDir returns the platform-appropriate default models directory.
//   - Linux/Mac: /home/user/.gleann/models
//   - Windows:   C:\Users\user\.gleann\models
func DefaultModelsDir() string {
	home, _ := os.UserHomeDir()
	return filepath.Join(home, ".gleann", "models")
}

// ExpandPath expands ~ and ~/ prefixes to the user's home directory
// and cleans the path using filepath.Clean for cross-platform correctness.
// On Windows, forward slashes in the path are converted to backslashes.
func ExpandPath(p string) string {
	if p == "" {
		return p
	}

	// Expand ~ prefix.
	if p == "~" {
		home, _ := os.UserHomeDir()
		return home
	}
	if strings.HasPrefix(p, "~/") || strings.HasPrefix(p, "~\\") {
		home, _ := os.UserHomeDir()
		p = filepath.Join(home, p[2:])
	}

	// On Windows, convert forward slashes from Linux-originated configs.
	if runtime.GOOS == "windows" {
		p = strings.ReplaceAll(p, "/", "\\")
	}

	return filepath.Clean(p)
}

// configPath returns the platform-appropriate config file path.
func configPath() string {
	home, _ := os.UserHomeDir()
	return filepath.Join(home, ".gleann", "config.json")
}

// SanitizeConfig strips provider-specific credentials/endpoints when that provider is not selected.
func SanitizeConfig(r *OnboardResult) {
	if r == nil {
		return
	}
	embIsOllama := strings.EqualFold(r.EmbeddingProvider, "ollama")
	llmIsOllama := strings.EqualFold(r.LLMProvider, "ollama")
	if r.EmbeddingProvider != "" || r.LLMProvider != "" {
		if !embIsOllama && !llmIsOllama {
			r.OllamaHost = ""
			r.OllamaAPIKey = ""
		}
	}

	embIsOpenAI := strings.EqualFold(r.EmbeddingProvider, "openai")
	llmIsOpenAI := strings.EqualFold(r.LLMProvider, "openai")
	if r.EmbeddingProvider != "" || r.LLMProvider != "" {
		if !embIsOpenAI && !llmIsOpenAI {
			r.OpenAIKey = ""
			r.OpenAIBaseURL = ""
		}
	}

	llmIsAnthropic := strings.EqualFold(r.LLMProvider, "anthropic")
	if r.LLMProvider != "" {
		if !llmIsAnthropic {
			r.AnthropicKey = ""
		}
	}
}

// mergeConfig overlays non-empty incoming values on top of existing configuration.
func mergeConfig(existing, incoming *OnboardResult) OnboardResult {
	if existing == nil {
		return *incoming
	}
	merged := *existing

	// Core providers & models
	if incoming.EmbeddingProvider != "" {
		merged.EmbeddingProvider = incoming.EmbeddingProvider
	}
	if incoming.EmbeddingModel != "" {
		merged.EmbeddingModel = incoming.EmbeddingModel
	}
	if incoming.CodeEmbeddingModel != "" {
		merged.CodeEmbeddingModel = incoming.CodeEmbeddingModel
	}
	if incoming.DocEmbeddingModel != "" {
		merged.DocEmbeddingModel = incoming.DocEmbeddingModel
	}
	if incoming.OllamaHost != "" {
		merged.OllamaHost = incoming.OllamaHost
	}
	if incoming.OllamaAPIKey != "" {
		merged.OllamaAPIKey = incoming.OllamaAPIKey
	}
	if incoming.OpenAIKey != "" {
		merged.OpenAIKey = incoming.OpenAIKey
	}
	if incoming.OpenAIBaseURL != "" {
		merged.OpenAIBaseURL = incoming.OpenAIBaseURL
	}
	if incoming.AnthropicKey != "" {
		merged.AnthropicKey = incoming.AnthropicKey
	}
	if incoming.LLMProvider != "" {
		merged.LLMProvider = incoming.LLMProvider
	}
	if incoming.LLMModel != "" {
		merged.LLMModel = incoming.LLMModel
	}
	if incoming.IndexDir != "" {
		merged.IndexDir = incoming.IndexDir
	}
	if incoming.Backend != "" {
		merged.Backend = incoming.Backend
	}
	if incoming.StorageMode != "" {
		merged.StorageMode = incoming.StorageMode
	}
	if incoming.MultimodalModel != "" {
		merged.MultimodalModel = incoming.MultimodalModel
	}

	// Booleans & toggles
	if incoming.Completed {
		merged.Completed = true
		merged.RerankEnabled = incoming.RerankEnabled
		merged.RerankModel = incoming.RerankModel
		merged.RerankProvider = incoming.RerankProvider
		merged.ServerEnabled = incoming.ServerEnabled
		merged.MCPEnabled = incoming.MCPEnabled
		if incoming.A2AEnabled != nil {
			merged.A2AEnabled = incoming.A2AEnabled
		}
	} else {
		if incoming.RerankEnabled {
			merged.RerankEnabled = true
			merged.RerankModel = incoming.RerankModel
			merged.RerankProvider = incoming.RerankProvider
		}
		if incoming.ServerEnabled {
			merged.ServerEnabled = true
		}
		if incoming.MCPEnabled {
			merged.MCPEnabled = true
		}
		if incoming.A2AEnabled != nil {
			merged.A2AEnabled = incoming.A2AEnabled
		}
	}

	if incoming.ServerAddr != "" {
		merged.ServerAddr = incoming.ServerAddr
	}
	if incoming.InstallPath != "" {
		merged.InstallPath = incoming.InstallPath
	}
	if incoming.InstallCompletions {
		merged.InstallCompletions = true
	}
	if incoming.Uninstall {
		merged.Uninstall = incoming.Uninstall
		merged.UninstallData = incoming.UninstallData
	}
	if incoming.LlamaCPPConfig.ModelStorageDir != "" {
		merged.LlamaCPPConfig = incoming.LlamaCPPConfig
	}
	if incoming.SystemPrompt != "" {
		merged.SystemPrompt = incoming.SystemPrompt
	}
	if incoming.Temperature > 0 {
		merged.Temperature = incoming.Temperature
	}
	if incoming.RepeatPenalty > 0 {
		merged.RepeatPenalty = incoming.RepeatPenalty
	}
	if incoming.MaxTokens > 0 {
		merged.MaxTokens = incoming.MaxTokens
	}
	if incoming.TopK > 0 {
		merged.TopK = incoming.TopK
	}
	if len(incoming.Roles) > 0 {
		merged.Roles = incoming.Roles
	}
	if len(incoming.FormatText) > 0 {
		merged.FormatText = incoming.FormatText
	}
	return merged
}

// SaveConfig persists the configuration to disk with deep merge.
// Exported so chat settings can call it after applying changes.
func SaveConfig(r OnboardResult) error {
	path := configPath()
	dir := filepath.Dir(path)
	if err := os.MkdirAll(dir, 0o700); err != nil {
		return err
	}

	existing := LoadSavedConfig()
	merged := mergeConfig(existing, &r)
	return saveExact(path, merged)
}

// saveExact writes merged as it is (no merge: an empty value clears the
// key), keeping the keys of config.json that OnboardResult does not model.
// The settings registry saves through it, so a field can be cleared.
func saveExact(path string, merged OnboardResult) error {
	if err := os.MkdirAll(filepath.Dir(path), 0o700); err != nil {
		return err
	}
	// Keys that OnboardResult does not model (search_config, chunk_config,
	// rate_limit, timezone, ...) live in the same file: preserve them.
	out := map[string]any{}
	if raw, rerr := os.ReadFile(path); rerr == nil && len(strings.TrimSpace(string(raw))) > 0 {
		if uerr := json.Unmarshal(raw, &out); uerr != nil {
			return fmt.Errorf("existing %s is not valid JSON (%v); fix or remove it — not overwritten", path, uerr)
		}
	}
	mergedJSON, err := json.Marshal(merged)
	if err != nil {
		return err
	}
	mergedMap := map[string]any{}
	if err := json.Unmarshal(mergedJSON, &mergedMap); err != nil {
		return err
	}
	for _, k := range onboardJSONKeys() {
		delete(out, k)
	}
	for k, v := range mergedMap {
		out[k] = v
	}
	data, err := json.MarshalIndent(out, "", "  ")
	if err != nil {
		return err
	}
	return writeSecretFile(path, data)
}

// onboardJSONKeys lists the JSON keys owned by OnboardResult.
func onboardJSONKeys() []string {
	t := reflect.TypeOf(OnboardResult{})
	keys := make([]string, 0, t.NumField())
	for i := 0; i < t.NumField(); i++ {
		name, _, _ := strings.Cut(t.Field(i).Tag.Get("json"), ",")
		if name != "" && name != "-" {
			keys = append(keys, name)
		}
	}
	return keys
}

// writeSecretFile writes data to path with mode 0600. The config holds API
// keys, so it must not be readable by other users; os.WriteFile only applies
// the mode when it creates the file, so existing files are tightened too.
func writeSecretFile(path string, data []byte) error {
	tmp, err := os.CreateTemp(filepath.Dir(path), ".config-*.tmp")
	if err != nil {
		return err
	}
	defer os.Remove(tmp.Name())
	if err := tmp.Chmod(0o600); err != nil {
		tmp.Close()
		return err
	}
	if _, err := tmp.Write(data); err != nil {
		tmp.Close()
		return err
	}
	if err := tmp.Close(); err != nil {
		return err
	}
	return os.Rename(tmp.Name(), path)
}

// UpdateConfig reads the existing config, applies the mutator function,
// and writes it back. Creates a new config if none exists.
func UpdateConfig(mutate func(cfg *OnboardResult)) error {
	cfg := LoadSavedConfig()
	if cfg == nil {
		cfg = &OnboardResult{}
	}
	mutate(cfg)
	return SaveConfig(*cfg)
}

// ConfigError reports a config.json that exists but is not valid JSON. Line
// and Column (1-based) locate the first offending byte; they are 0 when the
// error carries no offset.
type ConfigError struct {
	Path   string
	Line   int
	Column int
	Err    error
}

func (e *ConfigError) Error() string {
	if e.Line > 0 {
		return fmt.Sprintf("%s is not valid JSON at line %d, column %d: %v; fix it with 'gleann config edit' — the file was left untouched",
			e.Path, e.Line, e.Column, e.Err)
	}
	return fmt.Sprintf("%s is not valid JSON: %v; fix it with 'gleann config edit' — the file was left untouched", e.Path, e.Err)
}

func (e *ConfigError) Unwrap() error { return e.Err }

// newConfigError builds a ConfigError, turning the byte offset of a JSON
// syntax or type error into a line and column.
func newConfigError(path string, data []byte, err error) *ConfigError {
	ce := &ConfigError{Path: path, Err: err}
	var offset int64 = -1
	var syn *json.SyntaxError
	var typ *json.UnmarshalTypeError
	switch {
	case errors.As(err, &syn):
		offset = syn.Offset
	case errors.As(err, &typ):
		offset = typ.Offset
	}
	if offset < 0 {
		return ce
	}
	// Offset counts the bytes read, so the offending byte is at offset-1.
	pos := int(offset) - 1
	if pos < 0 {
		pos = 0
	}
	if pos > len(data) {
		pos = len(data)
	}
	ce.Line = 1 + bytes.Count(data[:pos], []byte{'\n'})
	ce.Column = pos - bytes.LastIndexByte(data[:pos], '\n')
	return ce
}

// ConfigFilePath returns the path of the saved config file.
func ConfigFilePath() string { return configPath() }

// LoadSavedConfigChecked reads the saved config like LoadSavedConfig but
// reports a config.json that cannot be parsed (a *ConfigError) instead of
// hiding it. A missing or empty file is not an error: it returns (nil, nil).
func LoadSavedConfigChecked() (*OnboardResult, error) {
	path := configPath()
	data, err := os.ReadFile(path)
	if err != nil {
		if os.IsNotExist(err) {
			return nil, nil
		}
		return nil, fmt.Errorf("reading %s: %w", path, err)
	}
	if len(bytes.TrimSpace(data)) == 0 {
		return nil, nil
	}
	var r OnboardResult
	if err := json.Unmarshal(data, &r); err != nil {
		return nil, newConfigError(path, data, err)
	}
	// Expand paths for cross-platform compatibility.
	if r.IndexDir != "" {
		r.IndexDir = ExpandPath(r.IndexDir)
	}
	return &r, nil
}

// LoadSavedConfig reads the saved config. Returns nil if not found or if the
// file cannot be parsed; commands call LoadSavedConfigChecked up front (see
// cmd/gleann) so a malformed file is reported rather than ignored.
// Paths in the config are expanded for the current platform.
func LoadSavedConfig() *OnboardResult {
	r, err := LoadSavedConfigChecked()
	if err != nil {
		return nil
	}
	return r
}
