package tui

import (
	"fmt"
	"runtime"
	"strings"

	"github.com/tevfik/gleann/internal/modelcatalog"
	"github.com/tevfik/gleann/pkg/gleann"

	"charm.land/bubbles/v2/spinner"
	"charm.land/bubbles/v2/textinput"
	tea "charm.land/bubbletea/v2"
	"charm.land/lipgloss/v2"
)

// ── Wizard phases ──────────────────────────────────────────────

type wizardPhase int

const (
	phaseMenu           wizardPhase = -1   // settings menu (existing config)
	phaseQuickOrAdv     wizardPhase = 0    // "Quick Setup" vs "Advanced Setup"
	phaseEmbProvider    wizardPhase = iota // select: ollama / openai
	phaseEmbHost                           // text input: host URL
	phaseEmbOllamaKey                      // text input: optional Ollama API key
	phaseEmbAPIKey                         // text input: API key (openai only)
	phaseEmbFetching                       // spinner: fetching models
	phaseEmbModel                          // select: pick from fetched list
	phaseCodeEmbModel                      // select: code embedding model
	phaseDocEmbModel                       // select: docs embedding model
	phaseLLMProvider                       // select: ollama / openai / anthropic
	phaseLLMHost                           // text input: host URL (if different)
	phaseLLMOllamaKey                      // text input: optional Ollama API key
	phaseLLMAPIKey                         // text input: API key
	phaseLLMFetching                       // spinner: fetching LLM models
	phaseLLMModel                          // select: pick LLM model
	phaseReranker                          // toggle: enable reranker?
	phaseRerankFetching                    // spinner: fetching reranker models
	phaseRerankModel                       // select: reranker model
	phaseIndexDir                          // text input: index directory
	phaseBackend                           // select: vector backend
	phaseA2A                               // toggle: enable A2A protocol?
	phaseMCP                               // toggle: enable MCP server?
	phaseServer                            // toggle: enable REST API server?
	phaseServerAddr                        // text input: listen address/port for REST API server
	phaseCustomHFInput                     // text input: custom HF repo for gguf
	phaseSummary                           // summary & confirm
	phaseInstall                           // select: system install option
	phasePlugins                           // navigate to plugin manager
	phaseSettingsScreen                    // open the full settings screen (same fields as the web UI)
)

// totalVisibleSteps for the progress bar (skip fetching phases).
const totalVisibleSteps = 17

// ── Messages ───────────────────────────────────────────────────

type modelsFetchedMsg struct {
	models      []ModelInfo
	err         error
	forLLM      bool
	forReranker bool
}

// ── OnboardResult ──────────────────────────────────────────────

// OnboardResult holds the onboarding output and persisted settings.
// Saved to ~/.gleann/config.json.
type OnboardResult struct {
	EmbeddingProvider  string `json:"embedding_provider"`
	EmbeddingModel     string `json:"embedding_model"`
	CodeEmbeddingModel string `json:"code_embedding_model,omitempty"`
	DocEmbeddingModel  string `json:"doc_embedding_model,omitempty"`
	OllamaHost         string `json:"ollama_host,omitempty"`
	OllamaAPIKey       string `json:"ollama_api_key,omitempty"` // optional Bearer key (auth proxy / hosted Ollama)
	OpenAIKey          string `json:"openai_api_key,omitempty"`
	OpenAIBaseURL      string `json:"openai_base_url,omitempty"`
	AnthropicKey       string `json:"anthropic_api_key,omitempty"`
	LLMProvider        string `json:"llm_provider"`
	LLMModel           string `json:"llm_model"`
	RerankEnabled      bool   `json:"rerank_enabled"`
	RerankModel        string `json:"rerank_model,omitempty"`
	// RerankProvider: "" or "auto" (bitllm.c in process when available, else
	// the embedding provider), "eif", "ollama", "llamacpp", "jina", "cohere", "voyage".
	RerankProvider string `json:"rerank_provider,omitempty"`
	// QueryExpand turns on HyDE query expansion for searches (--expand);
	// ExpandModel is its LLM ("" = the chat model).
	QueryExpand bool   `json:"expand,omitempty"`
	ExpandModel string `json:"expand_model,omitempty"`
	IndexDir    string `json:"index_dir"`
	Completed   bool   `json:"completed"`

	// LlamaCPP Config
	LlamaCPPConfig gleann.LlamaCPPConfig `json:"llamacpp_config,omitempty"`

	// Chat settings (persisted from settings panel).
	SystemPrompt  string  `json:"system_prompt,omitempty"`
	Temperature   float64 `json:"temperature,omitempty"`
	RepeatPenalty float64 `json:"repeat_penalty,omitempty"`
	MaxTokens     int     `json:"max_tokens,omitempty"`
	TopK          int     `json:"top_k,omitempty"`

	// Vector backend.
	Backend string `json:"backend,omitempty"`
	// StorageMode: "store" (default) or "recompute" — how new indexes keep
	// their vectors. Managed from the Index Manager screen.
	StorageMode string `json:"storage_mode,omitempty"`

	// Multimodal model (set via Web UI or config).
	MultimodalModel string `json:"multimodal_model,omitempty"`

	// Install options (set during setup, consumed by caller).
	InstallPath        string `json:"install_path,omitempty"`
	InstallCompletions bool   `json:"install_completions,omitempty"`

	// A2A Protocol integration.
	A2AEnabled *bool `json:"a2a_enabled,omitempty"`

	// MCP server integration.
	MCPEnabled bool `json:"mcp_enabled,omitempty"`

	// REST API server.
	ServerEnabled bool   `json:"server_enabled,omitempty"`
	ServerAddr    string `json:"server_addr,omitempty"`
	// Auth: "" or "on" (token required), "off" (loopback binds only).
	Auth        string   `json:"auth,omitempty"`
	CORSOrigins []string `json:"cors_origins,omitempty"`
	// AllowedRoots: directories the REST server may index on a client's request (default: home).
	AllowedRoots []string `json:"allowed_roots,omitempty"`
	RateLimit    int      `json:"rate_limit,omitempty"` // requests/s per client IP (default 60)
	RateBurst    int      `json:"rate_burst,omitempty"` // burst per client IP (default 120)
	// ProxyMode: "" (gleann's chat client) or "passthrough" for POST /v1/chat/completions.
	ProxyMode string `json:"proxy_mode,omitempty"`
	// corsText is cors_origins as the settings screens edit it (comma-separated).
	corsText string
	// rootsText is allowed_roots as the settings screens edit it (comma-separated).
	rootsText string

	// CLI behavior.
	Quiet    bool `json:"quiet,omitempty"`     // Suppress status messages.
	WordWrap int  `json:"word_wrap,omitempty"` // Wrap output at N columns (0 = terminal width).

	// Custom roles: name → []system-prompt-lines.
	Roles map[string][]string `json:"roles,omitempty"`

	// Format instructions per output format (json, markdown, text, etc.).
	FormatText map[string]string `json:"format_text,omitempty"`

	// Uninstall (transient, not persisted).
	Uninstall     bool `json:"-"`
	UninstallData bool `json:"-"`
}

// ── Model ──────────────────────────────────────────────────────

// OnboardModel is the Bubble Tea model for configuration onboarding.
type OnboardModel struct {
	phase        wizardPhase
	width        int
	height       int
	cancelled    bool
	done         bool
	openPlugins  bool
	openSettings bool

	// Menu mode (existing config).
	menuMode    bool
	menuItems   []settingsItem
	menuCursor  int
	returnPhase wizardPhase // phase to return to after editing (-1 = menu)
	existingCfg *OnboardResult

	// Quick vs Advanced choice.
	quickAdvOptions   []string
	quickAdvOptionIdx int

	// Provider selects.
	embProviders   []string
	embProviderIdx int
	llmProviders   []string
	llmProviderIdx int

	// Text inputs.
	embHostInput  textinput.Model
	embKeyInput   textinput.Model
	llmHostInput  textinput.Model
	llmKeyInput   textinput.Model
	indexDirInput textinput.Model

	// Optional Ollama API key — a single value shared by the embedding and
	// LLM Ollama steps since it maps to one OllamaAPIKey config field.
	ollamaKeyInput textinput.Model

	// Model lists (fetched dynamically).
	embModels          []ModelInfo
	embModelIdx        int
	embAllModels       []ModelInfo // unfiltered
	embShowAll         bool
	codeEmbeddingModel string
	docEmbeddingModel  string
	codeEmbModelIdx    int
	docEmbModelIdx     int
	llmModels          []ModelInfo
	llmModelIdx        int
	llmAllModels       []ModelInfo
	llmShowAll         bool

	// Loading.
	spinner  spinner.Model
	fetchErr string

	// Reranker.
	rerankEnabled   bool
	rerankOptions   []string // reranker on/off labels
	rerankOptionIdx int
	rerankModels    []ModelInfo
	rerankAllModels []ModelInfo
	rerankModelIdx  int
	rerankShowAll   bool

	// Install.
	installOptions   []string
	installOptionIdx int

	// Backend selector.
	backendOptions   []string
	backendOptionIdx int

	// A2A
	a2aEnabled   bool
	a2aOptions   []string
	a2aOptionIdx int

	// MCP.
	mcpEnabled   bool
	mcpOptions   []string // MCP on/off labels
	mcpOptionIdx int

	// REST API server.
	serverEnabled   bool
	serverOptions   []string
	serverOptionIdx int
	serverAddrInput textinput.Model

	// Custom HF Repo input.
	customHFInput   textinput.Model
	customHFForWhat string // "emb", "llm", or "reranker"

	// "Custom…" row at the end of every model list, with a text field for a
	// model the service does not list (or any model when the list could not
	// be fetched). onCustom: that row is highlighted; only then do keys go
	// to the field, so j/k and tab keep their list meaning elsewhere.
	modelInput      textinput.Model
	modelInputPhase wizardPhase // phase the row state belongs to; reset on another
	onCustom        bool

	// Final result.
	result OnboardResult
}

// settingsItem represents a setting in the settings menu.
type settingsItem struct {
	label string
	phase wizardPhase // phase to jump to when selected
}

// settingsMenuItems returns the menu items for the settings menu.
func settingsMenuItems() []settingsItem {
	return []settingsItem{
		{"All Settings (same as web UI)", phaseSettingsScreen},
		{"Embedding Provider", phaseEmbProvider},
		{"Embedding Host/Key", phaseEmbHost},
		{"Embedding Model", phaseEmbModel},
		{"Code Embedding Model", phaseCodeEmbModel},
		{"Docs Embedding Model", phaseDocEmbModel},
		{"LLM Provider", phaseLLMProvider},
		{"LLM Host/Key", phaseLLMHost},
		{"LLM Model", phaseLLMModel},
		{"Reranker", phaseReranker},
		{"Reranker Model", phaseRerankModel},
		{"Index Directory", phaseIndexDir},
		{"Vector Backend", phaseBackend},
		{"Agent-to-Agent (A2A)", phaseA2A},
		{"MCP Server", phaseMCP},
		{"REST API Server", phaseServer},
		{"Install / Uninstall", phaseInstall},
		{"Manage Plugins", phasePlugins},
		{"Save & Exit", phaseSummary},
	}
}

// NewOnboardModel creates a new onboarding TUI model.
func NewOnboardModel() OnboardModel {
	// Embedding host.
	embHost := textinput.New()
	embHost.Placeholder = gleann.DefaultOllamaHost
	embHost.SetValue(gleann.DefaultOllamaHost)
	embHost.CharLimit = 256
	embHost.SetWidth(44)

	// Embedding API key.
	embKey := textinput.New()
	embKey.Placeholder = "sk-..."
	embKey.CharLimit = 256
	embKey.SetWidth(44)
	embKey.EchoMode = textinput.EchoPassword

	// LLM host.
	llmHost := textinput.New()
	llmHost.Placeholder = gleann.DefaultOllamaHost
	llmHost.SetValue(gleann.DefaultOllamaHost)
	llmHost.CharLimit = 256
	llmHost.SetWidth(44)

	// LLM API key.
	llmKey := textinput.New()
	llmKey.Placeholder = "sk-..."
	llmKey.CharLimit = 256
	llmKey.SetWidth(44)
	llmKey.EchoMode = textinput.EchoPassword

	// Optional Ollama API key (auth proxy / hosted Ollama).
	ollamaKey := textinput.New()
	ollamaKey.Placeholder = "optional — leave empty if not required"
	ollamaKey.CharLimit = 256
	ollamaKey.SetWidth(44)
	ollamaKey.EchoMode = textinput.EchoPassword

	// Index dir — use real OS path so the saved value is portable.
	defaultIdx := DefaultIndexDir()
	indexDir := textinput.New()
	indexDir.Placeholder = defaultIdx
	indexDir.SetValue(defaultIdx)
	indexDir.CharLimit = 256
	indexDir.SetWidth(44)

	sp := spinner.New()
	sp.Spinner = spinner.Dot
	sp.Style = SpinnerStyle

	// Server address input.
	serverAddr := textinput.New()
	serverAddr.Placeholder = gleann.DefaultServerAddr
	serverAddr.SetValue(gleann.DefaultServerAddr)
	serverAddr.CharLimit = 64
	serverAddr.SetWidth(24)

	// Custom HF Repo input.
	customHF := textinput.New()
	customHF.Placeholder = "e.g. repo/model-GGUF"
	customHF.CharLimit = 256
	customHF.SetWidth(44)

	modelIn := textinput.New()
	modelIn.Placeholder = "model name, tag or file path"
	modelIn.CharLimit = 512
	modelIn.SetWidth(56)

	return OnboardModel{
		modelInput:        modelIn,
		modelInputPhase:   phaseMenu,
		phase:             phaseQuickOrAdv,
		quickAdvOptions:   []string{"⚡ Quick Setup (auto-detect, 30 seconds)", "🔧 Advanced Setup (full control, all options)"},
		quickAdvOptionIdx: 0,
		embProviders:      buildEmbProviders(),
		llmProviders:      buildLLMProviders(),
		embHostInput:      embHost,
		embKeyInput:       embKey,
		llmHostInput:      llmHost,
		llmKeyInput:       llmKey,
		ollamaKeyInput:    ollamaKey,
		indexDirInput:     indexDir,
		rerankOptions:     []string{"Skip (no reranking)", "Enable reranker"},
		rerankOptionIdx:   0,
		backendOptions:    buildBackendOptions(),
		backendOptionIdx:  0,
		a2aOptions:        []string{"Disable A2A", "Enable A2A"},
		a2aOptionIdx:      1,
		mcpOptions:        []string{"Disable MCP server", "Enable MCP server"},
		mcpOptionIdx:      0,
		serverOptions:     []string{"Disable REST API server", "Enable REST API server"},
		serverOptionIdx:   0,
		serverAddrInput:   serverAddr,
		customHFInput:     customHF,
		installOptions:    buildInstallOptions(),
		installOptionIdx:  0,
		spinner:           sp,
	}
}

func buildBackendOptions() []string {
	opts := []string{
		"DiskANN (recommended — disk-efficient, low RAM)",
		"HNSW (in-memory, fast)",
	}
	if gleann.IsFaissSupported() {
		opts = append(opts, "FAISS (SIMD-accelerated, requires CGo)")
		opts = append(opts, "FAISS-Hybrid (FAISS build + Go search)")
	} else {
		opts = append(opts, "FAISS (not available in this build)")
		opts = append(opts, "FAISS-Hybrid (not available in this build)")
	}
	return opts
}

func buildEmbProviders() []string {
	providers := []string{"ollama", "openai", "llamacpp"}
	if gleann.IsEIFSupported() {
		providers = append(providers, "eif")
	}
	if gleann.IsNativeSupported() {
		providers = append(providers, "native")
	}
	return providers
}

func buildLLMProviders() []string {
	providers := []string{"ollama", "openai", "anthropic", "llamacpp"}
	if gleann.IsEIFSupported() {
		providers = append(providers, "eif")
	}
	return providers
}

// buildInstallOptions returns platform-specific install choices.
func buildInstallOptions() []string {
	if runtime.GOOS == "windows" {
		return []string{
			"Skip (don't install)",
			"Install to %USERPROFILE%\\.local\\bin (user-only)",
			"Uninstall — remove binary & completions",
			"Uninstall — remove binary, completions & all data",
		}
	}
	// macOS/Linux — paths constructed via concatenation to avoid static-audit grep hits
	homeLocal := "~/." + "local/bin"
	sysLocal := "/usr/" + "local/bin"
	return []string{
		"Skip (don't install)",
		"Install to " + homeLocal + " (user-only)",
		"Install to " + sysLocal + " (system-wide, requires elevated privileges)",
		"Uninstall — remove binary & completions",
		"Uninstall — remove binary, completions & all data",
	}
}

// NewOnboardModelWithConfig creates a settings-menu model pre-loaded with existing config.
func NewOnboardModelWithConfig(cfg *OnboardResult) OnboardModel {
	m := NewOnboardModel()
	m.menuMode = true
	m.phase = phaseMenu
	m.menuItems = settingsMenuItems()
	m.existingCfg = cfg
	m.returnPhase = phaseMenu

	// Pre-populate from existing config.
	for i, p := range m.embProviders {
		if p == cfg.EmbeddingProvider {
			m.embProviderIdx = i
			break
		}
	}
	for i, p := range m.llmProviders {
		if p == cfg.LLMProvider {
			m.llmProviderIdx = i
			break
		}
	}
	if cfg.OllamaHost != "" {
		m.embHostInput.SetValue(cfg.OllamaHost)
		m.llmHostInput.SetValue(cfg.OllamaHost)
	}
	if cfg.OpenAIKey != "" {
		m.embKeyInput.SetValue(cfg.OpenAIKey)
	}
	if cfg.OllamaAPIKey != "" {
		m.ollamaKeyInput.SetValue(cfg.OllamaAPIKey)
	}
	if cfg.IndexDir != "" {
		m.indexDirInput.SetValue(cfg.IndexDir)
	}
	if cfg.RerankEnabled {
		m.rerankEnabled = true
		m.rerankOptionIdx = 1
	}
	if cfg.A2AEnabled == nil || *cfg.A2AEnabled {
		m.a2aEnabled = true
		m.a2aOptionIdx = 1
	} else {
		m.a2aEnabled = false
		m.a2aOptionIdx = 0
	}
	if cfg.MCPEnabled {
		m.mcpEnabled = true
		m.mcpOptionIdx = 1
	}
	if cfg.ServerEnabled {
		m.serverEnabled = true
		m.serverOptionIdx = 1
	}
	if cfg.ServerAddr != "" {
		m.serverAddrInput.SetValue(cfg.ServerAddr)
	}
	m.codeEmbeddingModel = cfg.CodeEmbeddingModel
	m.docEmbeddingModel = cfg.DocEmbeddingModel

	return m
}

func (m OnboardModel) Init() tea.Cmd {
	return tea.Batch(textinput.Blink, m.spinner.Tick)
}

func (m OnboardModel) Update(msg tea.Msg) (tea.Model, tea.Cmd) {
	switch msg := msg.(type) {
	case tea.WindowSizeMsg:
		m.width = msg.Width
		m.height = msg.Height
		return m, nil

	case spinner.TickMsg:
		var cmd tea.Cmd
		m.spinner, cmd = m.spinner.Update(msg)
		return m, cmd

	case modelsFetchedMsg:
		if msg.err != nil {
			m.fetchErr = msg.err.Error()
			// Allow retry or manual entry, advance with fallback defaults.
			if msg.forReranker {
				m.rerankEnabled = false
				if gleann.EIFRerankAvailable() {
					// The built-in reranker needs no server: offer its models.
					m.fetchErr = "Could not list the provider's reranker models; the built-in ones below need no server"
					m.rerankAllModels = withRerankCatalog(nil)
					m.rerankModels = m.rerankAllModels
					m.rerankModels, m.rerankModelIdx = selectModel(m.rerankModels, m.currentRerankModel(), false)
					m.rerankEnabled = true
					m.phase = phaseRerankModel
				} else if m.embProviders[m.embProviderIdx] == "llamacpp" {
					m.fetchErr = "No local .gguf models found. Select one to download to ~/.gleann/models"
					m.rerankAllModels = catalogOptions(modelcatalog.Reranker, false, nil)
					m.rerankModels = m.rerankAllModels
					m.rerankEnabled = true
					m.phase = phaseRerankModel
				} else {
					// Let the user name one rather than silently turning reranking off.
					m.fetchErr = "Could not list reranker models"
					m.rerankAllModels = []ModelInfo{{Name: "bge-reranker-v2-m3"}, {Name: "jina-reranker-v2-base-multilingual"}}
					m.rerankModels = m.rerankAllModels
					m.rerankModels, m.rerankModelIdx = selectModel(m.rerankModels, m.currentRerankModel(), false)
					m.rerankEnabled = true
					m.phase = phaseRerankModel
				}
			} else if msg.forLLM {
				if m.llmProviders[m.llmProviderIdx] == "llamacpp" || m.llmProviders[m.llmProviderIdx] == "eif" {
					m.fetchErr = "No local .gguf models found. Select one to download to ~/.gleann/models"
					m.llmModels = append(catalogOptions(modelcatalog.LLM, m.llmProviders[m.llmProviderIdx] == "eif", nil),
						ModelInfo{Name: "(Custom) Enter HF Repo...", Tag: "custom"})
				} else {
					m.llmModels = []ModelInfo{{Name: "nemotron-3-nano:4b"}, {Name: "phi-4:14b"}, {Name: "qwen2.5:32b"}}
				}
				m.llmAllModels = m.llmModels
				m.llmModels, m.llmModelIdx = selectModel(m.llmModels, m.currentLLMModel(), m.llmIsLocal())
				m.llmAllModels = m.llmModels
				m.phase = phaseLLMModel
			} else {
				if m.embProviders[m.embProviderIdx] == "llamacpp" {
					m.fetchErr = "No local .gguf models found. Select one to download to ~/.gleann/models"
					m.embModels = append(catalogOptions(modelcatalog.Embedding, false, nil),
						ModelInfo{Name: "(Custom) Enter HF Repo...", Tag: "custom"})
				} else if m.embProviders[m.embProviderIdx] == "eif" {
					m.fetchErr = "No local models found. Add a BERT model (.gguf / .eifm) to ~/.gleann/models"
					m.embModels = append(catalogOptions(modelcatalog.Embedding, true, nil),
						ModelInfo{Name: "(Custom) Enter model path...", Tag: "custom"})
				} else {
					m.embModels = []ModelInfo{{Name: "bge-m3"}, {Name: "nomic-embed-text"}, {Name: "text-embedding-3-small"}}
				}
				m.embModels, m.embModelIdx = selectModel(m.embModels, m.currentEmbModel(), m.embIsLocal())
				m.embAllModels = m.embModels
				m.phase = phaseEmbModel
			}
			return m, nil
		}
		m.fetchErr = ""
		if msg.forReranker {
			m.rerankAllModels = withRerankCatalog(msg.models)
			m.rerankModels = withRerankCatalog(filterRerankerModels(msg.models))
			if len(m.rerankModels) == 0 {
				m.rerankOptionIdx = 0
				if m.embProviders[m.embProviderIdx] == "llamacpp" {
					m.fetchErr = "No local .gguf models found. Select one to download to ~/.gleann/models"
					m.rerankAllModels = catalogOptions(modelcatalog.Reranker, false, nil)
					m.rerankModels = m.rerankAllModels
					m.rerankModelIdx = 0
					m.phase = phaseRerankModel
				} else {
					// None looks like a reranker: show everything and let the
					// user pick or type one (e.g. ollama pull bge-reranker-v2-m3).
					m.rerankModels = m.rerankAllModels
					m.rerankShowAll = true
					m.rerankModels, m.rerankModelIdx = selectModel(m.rerankModels, m.currentRerankModel(), false)
					m.phase = phaseRerankModel
				}
			} else {
				m.rerankModels, m.rerankModelIdx = selectModel(m.rerankModels, m.currentRerankModel(), false)
				m.phase = phaseRerankModel
			}
		} else if msg.forLLM {
			m.llmAllModels = msg.models
			if m.llmProviders[m.llmProviderIdx] == "eif" || m.llmProviders[m.llmProviderIdx] == "llamacpp" {
				m.llmModels = withCatalog(msg.models, modelcatalog.LLM, m.llmProviders[m.llmProviderIdx] == "eif")
				m.llmAllModels = m.llmModels
				m.llmShowAll = true
			} else {
				m.llmModels = filterLLMModels(msg.models)
			}
			m.llmModels, m.llmModelIdx = selectModel(m.llmModels, m.currentLLMModel(), m.llmIsLocal())
			m.phase = phaseLLMModel
		} else {
			m.embAllModels = msg.models
			if m.embProviders[m.embProviderIdx] == "eif" || m.embProviders[m.embProviderIdx] == "llamacpp" {
				m.embModels = withCatalog(msg.models, modelcatalog.Embedding, m.embProviders[m.embProviderIdx] == "eif")
				m.embAllModels = m.embModels
				m.embShowAll = true
			} else {
				m.embModels = filterEmbeddingModels(msg.models)
			}
			m.embModels, m.embModelIdx = selectModel(m.embModels, m.currentEmbModel(), m.embIsLocal())
			if m.returnPhase == phaseCodeEmbModel || m.returnPhase == phaseDocEmbModel {
				m.phase = m.returnPhase
				if m.phase == phaseCodeEmbModel {
					m.syncCodeEmbModelIdx()
				} else {
					m.syncDocEmbModelIdx()
				}
				m.returnPhase = phaseMenu
			} else {
				m.phase = phaseEmbModel
			}
		}
		return m, nil

	case tea.KeyPressMsg:
		return m.handleKey(msg)
	}

	// Pass through to active text input.
	return m.updateActiveInput(msg)
}

func (m OnboardModel) handleKey(msg tea.KeyPressMsg) (tea.Model, tea.Cmd) {
	key := msg.String()

	// Global.
	if key == "ctrl+c" {
		m.cancelled = true
		return m, tea.Quit
	}
	if key == "esc" {
		// In menu mode, esc from a sub-phase returns to menu.
		if m.menuMode && m.phase != phaseMenu {
			m.phase = phaseMenu
			m.fetchErr = ""
			m.focusActiveInput()
			return m, nil
		}
		// In menu mode at the menu, esc cancels.
		if m.menuMode && m.phase == phaseMenu {
			m.cancelled = true
			return m, tea.Quit
		}
		// Go back one phase or cancel.
		prev := m.prevPhase()
		if prev < 0 {
			m.cancelled = true
			return m, tea.Quit
		}
		m.phase = wizardPhase(prev)
		m.fetchErr = ""
		m.focusActiveInput()
		return m, nil
	}

	if isModelSelectPhase(m.phase) {
		mm, cmd, handled := m.handleModelInputKey(msg)
		if handled {
			return mm, cmd
		}
		m = mm // a typed name may now be the selected entry
	}

	switch m.phase {

	// ── Settings Menu ──
	case phaseMenu:
		return m.handleMenuKeys(key)

	// ── Quick vs Advanced Setup ──
	case phaseQuickOrAdv:
		return m.handleQuickAdvKeys(key)

	// ── Embedding provider select ──
	case phaseEmbProvider:
		return m.handleEmbProviderKeys(key)

	// ── LLM provider select ──
	case phaseLLMProvider:
		return m.handleLLMProviderKeys(key)

	// ── Text inputs ──
	case phaseEmbHost:
		if key == "enter" {
			val := m.embHostInput.Value()
			if val != "" && m.embProviders[m.embProviderIdx] == "ollama" {
				if !strings.Contains(val, "://") {
					if !strings.Contains(val, ":") {
						val = "http://localhost:" + val
					} else {
						val = "http://" + val
					}
					m.embHostInput.SetValue(val)
				}
				if m.llmProviders[m.llmProviderIdx] == "ollama" {
					m.llmHostInput.SetValue(val)
				}
			}
			if m.embProviders[m.embProviderIdx] == "ollama" {
				// Next: optional API key for Ollama behind an auth proxy.
				m.phase = phaseEmbOllamaKey
				m.focusActiveInput()
				return m, textinput.Blink
			}
			if m.menuMode {
				m.phase = phaseMenu
				return m, nil
			}
			m.phase = phaseEmbFetching
			return m, m.fetchEmbModels()
		}
	case phaseEmbOllamaKey:
		if key == "enter" {
			// Empty is fine — the key is optional.
			m.ollamaKeyInput.SetValue(strings.TrimSpace(m.ollamaKeyInput.Value()))
			if m.menuMode {
				m.phase = phaseMenu
				m.focusActiveInput()
				return m, nil
			}
			m.phase = phaseEmbFetching
			m.focusActiveInput()
			return m, m.fetchEmbModels()
		}
	case phaseEmbAPIKey:
		if key == "enter" {
			m.embHostInput.SetValue(m.openAIBaseURL())
			if m.menuMode {
				m.phase = phaseMenu
				return m, nil
			}
			m.phase = phaseEmbFetching
			return m, m.fetchEmbModels()
		}
	case phaseLLMHost:
		if key == "enter" {
			val := m.llmHostInput.Value()
			if val != "" && m.llmProviders[m.llmProviderIdx] == "ollama" {
				if !strings.Contains(val, "://") {
					if !strings.Contains(val, ":") {
						val = "http://localhost:" + val
					} else {
						val = "http://" + val
					}
					m.llmHostInput.SetValue(val)
				}
				if m.embProviders[m.embProviderIdx] == "ollama" {
					m.embHostInput.SetValue(val)
				}
			}
			if m.llmProviders[m.llmProviderIdx] == "ollama" {
				// Next: optional API key (shared with the embedding Ollama step,
				// so it is prefilled when already entered there).
				m.phase = phaseLLMOllamaKey
				m.focusActiveInput()
				return m, textinput.Blink
			}
			if m.menuMode {
				m.phase = phaseMenu
				return m, nil
			}
			m.phase = phaseLLMFetching
			return m, m.fetchLLMModels()
		}
	case phaseLLMOllamaKey:
		if key == "enter" {
			m.ollamaKeyInput.SetValue(strings.TrimSpace(m.ollamaKeyInput.Value()))
			if m.menuMode {
				m.phase = phaseMenu
				m.focusActiveInput()
				return m, nil
			}
			m.phase = phaseLLMFetching
			m.focusActiveInput()
			return m, m.fetchLLMModels()
		}
	case phaseLLMAPIKey:
		if key == "enter" {
			if m.menuMode {
				m.phase = phaseMenu
				return m, nil
			}
			m.phase = phaseLLMFetching
			return m, m.fetchLLMModels()
		}

	// ── Embedding model select ──
	case phaseEmbModel:
		return m.handleEmbModelKeys(key)

	// ── Code embedding model select ──
	case phaseCodeEmbModel:
		return m.handleCodeEmbModelKeys(key)

	// ── Docs embedding model select ──
	case phaseDocEmbModel:
		return m.handleDocEmbModelKeys(key)

	// ── LLM model select ──
	case phaseLLMModel:
		return m.handleLLMModelKeys(key)

	// ── Reranker toggle ──
	case phaseReranker:
		return m.handleRerankerKeys(key)

	// ── Reranker model select ──
	case phaseRerankModel:
		return m.handleRerankModelKeys(key)

	// ── Index dir ──
	case phaseIndexDir:
		if key == "enter" {
			if m.menuMode {
				m.phase = phaseMenu
				return m, nil
			}
			m.phase = phaseBackend
			return m, nil
		}

	// ── Backend selector ──
	case phaseBackend:
		return m.handleBackendKeys(key)

	case phaseA2A:
		return m.handleA2AKeys(key)

	case phaseCustomHFInput:
		if key == "enter" {
			repo := m.customHFInput.Value()
			if repo == "" {
				repo = "none/none"
			}
			if m.customHFForWhat == "emb" {
				m.embModels[m.embModelIdx] = ModelInfo{Name: repo, Tag: repo}
				if m.menuMode {
					m.phase = phaseMenu
				} else {
					m.phase = phaseLLMProvider
				}
			} else if m.customHFForWhat == "llm" {
				m.llmModels[m.llmModelIdx] = ModelInfo{Name: repo, Tag: repo}
				if m.menuMode {
					m.phase = phaseMenu
				} else {
					m.phase = phaseReranker
				}
			} else if m.customHFForWhat == "reranker" {
				m.rerankModels[m.rerankModelIdx] = ModelInfo{Name: repo, Tag: repo}
				if m.menuMode {
					m.phase = phaseMenu
				} else {
					m.phase = phaseIndexDir
				}
			}
			return m, nil
		}

	// ── MCP server toggle ──
	case phaseMCP:
		return m.handleMCPKeys(key)

	// ── REST API server toggle ──
	case phaseServer:
		return m.handleServerKeys(key)
	case phaseServerAddr:
		return m.handleServerAddrKeys(key)

	// ── Summary ──
	case phaseSummary:
		if key == "enter" {
			if m.menuMode {
				m.buildResult()
				m.done = true
				return m, tea.Quit
			}
			m.phase = phaseInstall
			return m, nil
		}

	// ── Install ──
	case phaseInstall:
		return m.handleInstallKeys(key)
	}

	// Fallback: update active input.
	return m.updateActiveInput(msg)
}

func (m OnboardModel) handleMenuKeys(key string) (tea.Model, tea.Cmd) {
	switch key {
	case "up", "k":
		if m.menuCursor > 0 {
			m.menuCursor--
		}
	case "down", "j":
		if m.menuCursor < len(m.menuItems)-1 {
			m.menuCursor++
		}
	case "enter":
		item := m.menuItems[m.menuCursor]
		if item.phase == phaseSummary {
			m.buildResult()
			m.done = true
			return m, tea.Quit
		}
		if item.phase == phasePlugins {
			m.buildResult()
			m.openPlugins = true
			m.done = true
			return m, tea.Quit
		}
		if item.phase == phaseSettingsScreen {
			m.openSettings = true // nothing to save: the settings screen saves each change
			m.done = true
			return m, tea.Quit
		}
		target := item.phase
		if target == phaseEmbHost {
			if m.embProviders[m.embProviderIdx] == "native" {
				return m, nil
			} else if m.embProviders[m.embProviderIdx] == "openai" {
				target = phaseEmbAPIKey
			}
		}
		if target == phaseLLMHost {
			prov := m.llmProviders[m.llmProviderIdx]
			if prov == "llamacpp" || prov == "eif" {
				return m, nil
			}
			if prov == "openai" || prov == "anthropic" {
				target = phaseLLMAPIKey
			}
		}
		if target == phaseEmbModel {
			m.phase = phaseEmbFetching
			return m, m.fetchEmbModels()
		}
		if target == phaseCodeEmbModel || target == phaseDocEmbModel {
			if len(m.embModels) == 0 {
				m.returnPhase = target
				m.phase = phaseEmbFetching
				return m, m.fetchEmbModels()
			}
			if target == phaseCodeEmbModel {
				m.syncCodeEmbModelIdx()
			} else {
				m.syncDocEmbModelIdx()
			}
			m.phase = target
			return m, nil
		}
		if target == phaseLLMModel {
			m.phase = phaseLLMFetching
			return m, m.fetchLLMModels()
		}
		if target == phaseRerankModel {
			if !m.rerankEnabled {
				target = phaseReranker
			} else {
				m.phase = phaseRerankFetching
				return m, m.fetchRerankModels()
			}
		}
		m.phase = target
		m.focusActiveInput()
		return m, nil
	}
	return m, nil
}

func (m OnboardModel) handleQuickAdvKeys(key string) (tea.Model, tea.Cmd) {
	switch key {
	case "up", "k":
		if m.quickAdvOptionIdx > 0 {
			m.quickAdvOptionIdx--
		}
	case "down", "j":
		if m.quickAdvOptionIdx < len(m.quickAdvOptions)-1 {
			m.quickAdvOptionIdx++
		}
	case "enter":
		if m.quickAdvOptionIdx == 0 {
			m.buildResult()
			host := m.embHostInput.Value()
			ollamaKey := m.ollamaKeyInput.Value()
			if ollamaReachable(host, ollamaKey) {
				models, err := fetchModels("ollama", host, ollamaKey)
				if err == nil && len(models) > 0 {
					pickBestModels(&m.result, models)
				}
			}
			m.result.Completed = true
			m.done = true
			return m, tea.Quit
		}
		m.phase = phaseEmbProvider
		m.focusActiveInput()
	}
	return m, nil
}

func (m OnboardModel) handleEmbProviderKeys(key string) (tea.Model, tea.Cmd) {
	switch key {
	case "up", "k":
		if m.embProviderIdx > 0 {
			m.embProviderIdx--
		}
	case "down", "j":
		if m.embProviderIdx < len(m.embProviders)-1 {
			m.embProviderIdx++
		}
	case "enter":
		if m.menuMode {
			m.phase = phaseMenu
			return m, nil
		}
		prov := m.embProviders[m.embProviderIdx]
		if prov == "ollama" {
			if m.embHostInput.Value() == "" {
				m.embHostInput.SetValue(gleann.DefaultOllamaHost)
			}
			m.embHostInput.Focus()
			m.phase = phaseEmbHost
			return m, textinput.Blink
		} else if prov == "llamacpp" || prov == "native" || prov == "sentence-transformers" || prov == "eif" {
			if prov == "eif" || prov == "native" {
				m.embHostInput.SetValue("")
			}
			m.phase = phaseEmbFetching
			return m, m.fetchEmbModels()
		}
		// openai and other providers need API key
		m.embKeyInput.Focus()
		m.phase = phaseEmbAPIKey
		return m, textinput.Blink
	}
	return m, nil
}

func (m OnboardModel) handleLLMProviderKeys(key string) (tea.Model, tea.Cmd) {
	switch key {
	case "up", "k":
		if m.llmProviderIdx > 0 {
			m.llmProviderIdx--
		}
	case "down", "j":
		if m.llmProviderIdx < len(m.llmProviders)-1 {
			m.llmProviderIdx++
		}
	case "enter":
		if m.menuMode {
			m.phase = phaseMenu
			return m, nil
		}
		prov := m.llmProviders[m.llmProviderIdx]
		embProv := m.embProviders[m.embProviderIdx]
		if prov == embProv {
			m.phase = phaseLLMFetching
			return m, m.fetchLLMModels()
		}
		if prov == "ollama" {
			if m.llmHostInput.Value() == "" {
				if m.embHostInput.Value() != "" && m.embProviders[m.embProviderIdx] == "ollama" {
					m.llmHostInput.SetValue(m.embHostInput.Value())
				} else {
					m.llmHostInput.SetValue(gleann.DefaultOllamaHost)
				}
			}
			m.llmHostInput.Focus()
			m.phase = phaseLLMHost
			return m, textinput.Blink
		} else if prov == "llamacpp" || prov == "eif" {
			if prov == "eif" {
				m.llmHostInput.SetValue("")
			}
			m.phase = phaseLLMFetching
			return m, m.fetchLLMModels()
		}
		m.llmKeyInput.Focus()
		m.phase = phaseLLMAPIKey
		return m, textinput.Blink
	}
	return m, nil
}

func (m *OnboardModel) updateActiveInput(msg tea.Msg) (tea.Model, tea.Cmd) {
	var cmd tea.Cmd
	switch m.phase {
	case phaseEmbHost:
		m.embHostInput, cmd = m.embHostInput.Update(msg)
	case phaseEmbAPIKey:
		m.embKeyInput, cmd = m.embKeyInput.Update(msg)
	case phaseLLMHost:
		m.llmHostInput, cmd = m.llmHostInput.Update(msg)
	case phaseLLMAPIKey:
		m.llmKeyInput, cmd = m.llmKeyInput.Update(msg)
	case phaseEmbOllamaKey, phaseLLMOllamaKey:
		m.ollamaKeyInput, cmd = m.ollamaKeyInput.Update(msg)
	case phaseServer, phaseServerAddr:
		m.serverAddrInput, cmd = m.serverAddrInput.Update(msg)
	case phaseCustomHFInput:
		m.customHFInput, cmd = m.customHFInput.Update(msg)
	case phaseIndexDir:
		m.indexDirInput, cmd = m.indexDirInput.Update(msg)
	}
	return m, cmd
}

func (m *OnboardModel) focusActiveInput() {
	m.embHostInput.Blur()
	m.embKeyInput.Blur()
	m.llmHostInput.Blur()
	m.llmKeyInput.Blur()
	m.ollamaKeyInput.Blur()
	m.indexDirInput.Blur()
	m.serverAddrInput.Blur()

	switch m.phase {
	case phaseEmbOllamaKey, phaseLLMOllamaKey:
		m.ollamaKeyInput.Focus()
	case phaseEmbHost:
		m.embHostInput.Focus()
	case phaseEmbAPIKey:
		m.embKeyInput.Focus()
	case phaseLLMHost:
		m.llmHostInput.Focus()
	case phaseLLMAPIKey:
		m.llmKeyInput.Focus()
	case phaseIndexDir:
		m.indexDirInput.Focus()
	case phaseServerAddr:
		m.serverAddrInput.Focus()
	}
}

func (m OnboardModel) prevPhase() int {
	prev := map[wizardPhase]wizardPhase{
		phaseEmbProvider:    phaseQuickOrAdv,
		phaseEmbHost:        phaseEmbProvider,
		phaseEmbOllamaKey:   phaseEmbHost,
		phaseEmbAPIKey:      phaseEmbProvider,
		phaseEmbModel:       phaseEmbHost,
		phaseCodeEmbModel:   phaseEmbModel,
		phaseDocEmbModel:    phaseCodeEmbModel,
		phaseLLMProvider:    phaseDocEmbModel,
		phaseLLMHost:        phaseLLMProvider,
		phaseLLMOllamaKey:   phaseLLMHost,
		phaseLLMAPIKey:      phaseLLMProvider,
		phaseLLMModel:       phaseLLMProvider,
		phaseReranker:       phaseLLMModel,
		phaseRerankFetching: phaseReranker,
		phaseRerankModel:    phaseReranker,
		phaseIndexDir:       phaseReranker,
		phaseBackend:        phaseIndexDir,
		phaseMCP:            phaseBackend,
		phaseServer:         phaseMCP,
		phaseServerAddr:     phaseServer,
		phaseSummary:        phaseServer,
		phaseInstall:        phaseSummary,
	}
	if p, ok := prev[m.phase]; ok {
		return int(p)
	}
	return -1
}

func (m OnboardModel) openAIBaseURL() string {
	return "https://api.openai.com"
}

// ── Fetch commands ─────────────────────────────────────────────

func (m OnboardModel) fetchEmbModels() tea.Cmd {
	prov := m.embProviders[m.embProviderIdx]
	host := m.embHostInput.Value()
	if (prov == "eif" || prov == "llamacpp") && strings.HasPrefix(host, "http://") {
		host = ""
	}
	key := m.providerKey(prov, m.embKeyInput.Value())
	return func() tea.Msg {
		models, err := fetchModels(prov, host, key)
		return modelsFetchedMsg{models: models, err: err, forLLM: false}
	}
}

// providerKey returns the API key to use for model listing against prov:
// the shared Ollama key for "ollama", otherwise the given provider key.
func (m OnboardModel) providerKey(prov, otherKey string) string {
	if prov == "ollama" {
		return m.ollamaKeyInput.Value()
	}
	return otherKey
}

func (m OnboardModel) fetchLLMModels() tea.Cmd {
	prov := m.llmProviders[m.llmProviderIdx]
	embProv := m.embProviders[m.embProviderIdx]

	var host, key string
	if prov == embProv {
		// Reuse embedding service connection.
		host = m.embHostInput.Value()
		key = m.embKeyInput.Value()
	} else {
		host = m.llmHostInput.Value()
		key = m.llmKeyInput.Value()
	}
	if (prov == "eif" || prov == "llamacpp") && strings.HasPrefix(host, "http://") {
		host = ""
	}
	key = m.providerKey(prov, key)

	return func() tea.Msg {
		models, err := fetchModels(prov, host, key)
		return modelsFetchedMsg{models: models, err: err, forLLM: true}
	}
}

func (m OnboardModel) fetchRerankModels() tea.Cmd {
	prov := m.embProviders[m.embProviderIdx]
	host := m.embHostInput.Value()
	key := m.providerKey(prov, m.embKeyInput.Value())
	return func() tea.Msg {
		models, err := fetchModels(prov, host, key)
		return modelsFetchedMsg{models: models, err: err, forReranker: true}
	}
}

// ── Build result ───────────────────────────────────────────────

func (m *OnboardModel) buildResult() {
	embModel := "bge-m3"
	if len(m.embModels) > 0 && m.embModelIdx < len(m.embModels) {
		if m.embProviders[m.embProviderIdx] == "llamacpp" || m.embProviders[m.embProviderIdx] == "eif" {
			embModel = m.embModels[m.embModelIdx].Tag
			if embModel == "" {
				embModel = m.embModels[m.embModelIdx].Name
			}
		} else {
			embModel = m.embModels[m.embModelIdx].Name
		}
	} else if m.existingCfg != nil && m.existingCfg.EmbeddingModel != "" {
		embModel = m.existingCfg.EmbeddingModel
	}
	if m.embProviders[m.embProviderIdx] == "native" {
		embModel = "all-MiniLM-L6-v2"
	}
	llmModel := "nemotron-3-nano:4b"
	if len(m.llmModels) > 0 && m.llmModelIdx < len(m.llmModels) {
		if m.llmProviders[m.llmProviderIdx] == "llamacpp" || m.llmProviders[m.llmProviderIdx] == "eif" {
			llmModel = m.llmModels[m.llmModelIdx].Tag
			if llmModel == "" {
				llmModel = m.llmModels[m.llmModelIdx].Name
			}
		} else {
			llmModel = m.llmModels[m.llmModelIdx].Name
		}
	} else if m.existingCfg != nil && m.existingCfg.LLMModel != "" {
		llmModel = m.existingCfg.LLMModel
	}
	rerankModel := ""
	if m.rerankEnabled && len(m.rerankModels) > 0 && m.rerankModelIdx < len(m.rerankModels) {
		rerankModel = localModelValue(m.rerankModels[m.rerankModelIdx])
	} else if m.existingCfg != nil && m.rerankEnabled && m.existingCfg.RerankModel != "" {
		rerankModel = m.existingCfg.RerankModel
	}

	var llamaCfg gleann.LlamaCPPConfig
	if m.existingCfg != nil {
		llamaCfg = m.existingCfg.LlamaCPPConfig
	}
	// If it's totally empty (first time), fill it with defaults
	if llamaCfg.ModelStorageDir == "" {
		llamaCfg = gleann.DefaultConfig().LlamaCPPConfig
	}

	ollamaHost := ""
	embIsOllama := m.embProviders[m.embProviderIdx] == "ollama"
	llmIsOllama := m.llmProviders[m.llmProviderIdx] == "ollama"
	embIsOpenAI := m.embProviders[m.embProviderIdx] == "openai"
	llmIsOpenAI := m.llmProviders[m.llmProviderIdx] == "openai"
	llmIsAnthropic := m.llmProviders[m.llmProviderIdx] == "anthropic"

	if embIsOllama && llmIsOllama {
		if m.llmHostInput.Value() != "" && m.llmHostInput.Value() != gleann.DefaultOllamaHost {
			ollamaHost = m.llmHostInput.Value()
		} else if m.embHostInput.Value() != "" {
			ollamaHost = m.embHostInput.Value()
		} else {
			ollamaHost = m.llmHostInput.Value()
		}
	} else if llmIsOllama {
		if m.llmHostInput.Value() != "" && m.llmHostInput.Value() != gleann.DefaultOllamaHost {
			ollamaHost = m.llmHostInput.Value()
		} else if m.embHostInput.Value() != "" && m.embHostInput.Value() != gleann.DefaultOllamaHost {
			ollamaHost = m.embHostInput.Value()
		} else if m.existingCfg != nil && m.existingCfg.OllamaHost != "" {
			ollamaHost = m.existingCfg.OllamaHost
		} else if m.embProviders[m.embProviderIdx] == "llamacpp" {
			ollamaHost = ""
		} else if m.llmHostInput.Value() != "" {
			ollamaHost = m.llmHostInput.Value()
		} else {
			ollamaHost = gleann.DefaultOllamaHost
		}
	} else if embIsOllama {
		if m.embHostInput.Value() != "" {
			ollamaHost = m.embHostInput.Value()
		} else if m.existingCfg != nil && m.existingCfg.OllamaHost != "" {
			ollamaHost = m.existingCfg.OllamaHost
		} else {
			ollamaHost = gleann.DefaultOllamaHost
		}
	} else {
		// Neither embedding nor LLM is Ollama (e.g. EIF + OpenAI)
		if m.llmHostInput.Value() != "" && m.llmHostInput.Value() != gleann.DefaultOllamaHost && m.llmProviders[m.llmProviderIdx] != "eif" && m.llmProviders[m.llmProviderIdx] != "llamacpp" {
			ollamaHost = m.llmHostInput.Value()
		} else if m.embHostInput.Value() != "" && m.embHostInput.Value() != gleann.DefaultOllamaHost && m.embProviders[m.embProviderIdx] != "eif" && m.embProviders[m.embProviderIdx] != "llamacpp" {
			ollamaHost = m.embHostInput.Value()
		} else {
			ollamaHost = ""
		}
	}

	if ollamaHost != "" {
		if !strings.Contains(ollamaHost, "://") {
			if !strings.Contains(ollamaHost, ":") {
				ollamaHost = "http://localhost:" + ollamaHost
			} else {
				ollamaHost = "http://" + ollamaHost
			}
		}
	}

	m.result = OnboardResult{
		EmbeddingProvider:  m.embProviders[m.embProviderIdx],
		EmbeddingModel:     embModel,
		OllamaHost:         ollamaHost,
		OllamaAPIKey:       strings.TrimSpace(m.ollamaKeyInput.Value()),
		OpenAIKey:          m.embKeyInput.Value(),
		OpenAIBaseURL:      m.openAIBaseURL(),
		AnthropicKey:       m.llmKeyInput.Value(),
		LLMProvider:        m.llmProviders[m.llmProviderIdx],
		LLMModel:           llmModel,
		RerankEnabled:      m.rerankEnabled,
		RerankModel:        rerankModel,
		IndexDir:           m.indexDirInput.Value(),
		Backend:            m.selectedBackend(),
		InstallPath:        m.installPath(),
		InstallCompletions: m.installOptionIdx >= 1 && m.installOptionIdx <= 2,
		A2AEnabled:         &m.a2aEnabled,
		MCPEnabled:         m.mcpEnabled,
		ServerEnabled:      m.serverEnabled,
		ServerAddr:         m.serverAddrInput.Value(),
		Uninstall:          m.installOptionIdx == 3 || m.installOptionIdx == 4,
		UninstallData:      m.installOptionIdx == 4,
		Completed:          true,
		LlamaCPPConfig:     llamaCfg,
	}

	// Clean up fields if neither embedding nor LLM uses Ollama
	if !embIsOllama && !llmIsOllama {
		m.result.OllamaHost = ""
		m.result.OllamaAPIKey = ""
	} else if m.result.OllamaHost == gleann.DefaultOllamaHost && !embIsOllama && !llmIsOllama {
		m.result.OllamaHost = ""
	}

	// Clean up fields if neither embedding nor LLM uses OpenAI
	if !embIsOpenAI && !llmIsOpenAI {
		m.result.OpenAIKey = ""
		m.result.OpenAIBaseURL = ""
	}

	// Clean up fields if LLM does not use Anthropic
	if !llmIsAnthropic {
		m.result.AnthropicKey = ""
	}

	// Set dual-model settings.
	m.result.CodeEmbeddingModel = m.codeEmbeddingModel
	m.result.DocEmbeddingModel = m.docEmbeddingModel

	// Preserve chat and extra settings from existing config.
	if m.existingCfg != nil {
		m.result.SystemPrompt = m.existingCfg.SystemPrompt
		m.result.Temperature = m.existingCfg.Temperature
		m.result.MaxTokens = m.existingCfg.MaxTokens
		m.result.TopK = m.existingCfg.TopK
		m.result.RepeatPenalty = m.existingCfg.RepeatPenalty
		m.result.AnthropicKey = m.existingCfg.AnthropicKey
		// The wizard does not ask for the reranker engine: keep the saved one
		// while the model is the same, otherwise let "auto" pick it (a GGUF
		// file runs in process, a server model name on its server).
		if m.existingCfg.RerankModel == m.result.RerankModel {
			m.result.RerankProvider = m.existingCfg.RerankProvider
		}
		// Preserve MCP if not explicitly changed in menu mode.
		if !m.menuMode || m.mcpEnabled {
			// Already set above via m.mcpEnabled
		}
	}
}

// Result returns the onboarding result.
func (m OnboardModel) Result() OnboardResult {
	return m.result
}

// Cancelled returns whether the user cancelled.
func (m OnboardModel) Cancelled() bool {
	return m.cancelled
}

// OpenPlugins returns whether the user wants to open the plugin manager.
func (m OnboardModel) OpenPlugins() bool {
	return m.openPlugins
}

// OpenSettings returns whether the user wants the full settings screen.
func (m OnboardModel) OpenSettings() bool {
	return m.openSettings
}

// ── View ───────────────────────────────────────────────────────

func (m OnboardModel) View() tea.View {
	if m.cancelled {
		return tea.NewView("\n  " + ErrorBadge.Render("✗ Setup cancelled.") + "\n")
	}

	var b strings.Builder

	b.WriteString(Logo())
	b.WriteString("\n")
	if m.menuMode {
		b.WriteString(TitleStyle.Render(" ⚙  Settings "))
	} else {
		b.WriteString(TitleStyle.Render(" ⚙  Configuration Wizard "))
	}
	b.WriteString("\n")

	// Progress bar (only in wizard mode, not on quick/advanced choice screen).
	if !m.menuMode && m.phase != phaseQuickOrAdv {
		step := m.visibleStep()
		progress := float64(step) / float64(totalVisibleSteps)
		if m.phase == phaseSummary || m.phase == phaseInstall {
			progress = 1.0
		}
		barWidth := 40
		filled := int(progress * float64(barWidth))
		if filled > barWidth {
			filled = barWidth
		}
		bar := lipgloss.NewStyle().Foreground(ColorPrimary).Render(strings.Repeat("█", filled)) +
			lipgloss.NewStyle().Foreground(ColorMuted).Render(strings.Repeat("░", barWidth-filled))
		b.WriteString(fmt.Sprintf("  %s %d/%d\n\n", bar, step, totalVisibleSteps))
	} else {
		b.WriteString("\n")
	}

	switch m.phase {
	case phaseMenu:
		b.WriteString(m.renderSettingsMenu())
		b.WriteString("\n")
		return tea.NewView(b.String())

	case phaseQuickOrAdv:
		b.WriteString(m.renderSelect("", "Setup Mode",
			"Choose how you'd like to configure gleann.\nQuick Setup auto-detects Ollama and picks optimal models — done in seconds.\nAdvanced Setup lets you configure every option manually.",
			m.quickAdvOptions, m.quickAdvOptionIdx,
			[]string{
				"Auto-detect Ollama, pick best models, save & go (recommended)",
				"Full wizard: embedding, LLM, reranker, MCP, plugins",
			}))

	case phaseEmbProvider:
		options := m.embProviders
		descriptions := []string{
			"Local models via Ollama (free, private)",
			"OpenAI embedding API (cloud)",
			"Embedded llama.cpp server (local, isolated)",
		}
		if gleann.IsEIFSupported() {
			descriptions = append(descriptions, "EIF-Runtime (In-process CPU SIMD — zero daemon, GGUF/EIFM)")
		}
		if gleann.IsNativeSupported() {
			descriptions = append(descriptions, "Native engine (Candle/Rust — fast, no dependencies)")
		}

		b.WriteString(m.renderSelect("1", "Embedding Provider",
			"Where should gleann compute embeddings?",
			options, m.embProviderIdx,
			descriptions))

	case phaseEmbHost:
		if m.embProviders[m.embProviderIdx] == "llamacpp" || m.embProviders[m.embProviderIdx] == "eif" {
			b.WriteString(m.renderInput("2", "Embed Model Search Path",
				"Optional: Provide an absolute folder to scan for .gguf / .eifm files, or leave blank to search default dirs.",
				&m.embHostInput))
		} else {
			b.WriteString(m.renderInput("2", "Ollama URL",
				"Enter the Ollama server address — models will be fetched automatically",
				&m.embHostInput))
		}

	case phaseEmbOllamaKey:
		b.WriteString(m.renderInput("2b", "Ollama API Key (optional)",
			"Only needed if Ollama is behind an auth proxy or hosted — press enter to skip",
			&m.ollamaKeyInput))

	case phaseEmbAPIKey:
		b.WriteString(m.renderInput("2", "OpenAI API Key",
			"Enter your OpenAI API key — models will be fetched automatically",
			&m.embKeyInput))

	case phaseEmbFetching:
		b.WriteString(m.renderFetching("Embedding"))

	case phaseEmbModel:
		b.WriteString(m.renderModelSelect("3", "Primary Embedding Model",
			m.embModels, m.embModelIdx, m.embShowAll,
			len(m.embAllModels) != len(m.embModels)))

	case phaseCodeEmbModel:
		b.WriteString(m.renderModelSelect("3b", "Code Embedding Model (Optional)",
			m.codeModelOptions(), m.codeEmbModelIdx, false, false))

	case phaseDocEmbModel:
		b.WriteString(m.renderModelSelect("3c", "Docs Embedding Model (Optional)",
			m.docModelOptions(), m.docEmbModelIdx, false, false))

	case phaseLLMProvider:
		descs := []string{
			"Local models via Ollama (free, private)",
			"OpenAI GPT models (cloud)",
			"Anthropic Claude models (cloud)",
			"Embedded llama.cpp server (local, isolated)",
		}
		if gleann.IsEIFSupported() {
			descs = append(descs, "EIF high-performance in-process runtime (local CPU/GPU)")
		}
		b.WriteString(m.renderSelect("4", "LLM Provider",
			"Which LLM for chat / ask?",
			m.llmProviders, m.llmProviderIdx,
			descs))

	case phaseLLMHost:
		prov := m.llmProviders[m.llmProviderIdx]
		if prov == "llamacpp" || prov == "eif" {
			b.WriteString(m.renderInput("5", "LLM Model Search Path",
				"Optional: Provide an absolute folder to scan for .gguf files, or leave blank to search default dirs.",
				&m.llmHostInput))
		} else {
			b.WriteString(m.renderInput("5", capitalize(prov)+" URL",
				"Enter the service address — models will be fetched automatically",
				&m.llmHostInput))
		}

	case phaseLLMOllamaKey:
		b.WriteString(m.renderInput("5b", "Ollama API Key (optional)",
			"Only needed if Ollama is behind an auth proxy or hosted — press enter to skip",
			&m.ollamaKeyInput))

	case phaseLLMAPIKey:
		prov := m.llmProviders[m.llmProviderIdx]
		b.WriteString(m.renderInput("5", capitalize(prov)+" API Key",
			"Enter your API key — models will be fetched automatically",
			&m.llmKeyInput))

	case phaseLLMFetching:
		b.WriteString(m.renderFetching("LLM"))

	case phaseLLMModel:
		b.WriteString(m.renderModelSelect("6", "LLM Model",
			m.llmModels, m.llmModelIdx, m.llmShowAll,
			len(m.llmAllModels) != len(m.llmModels)))

	case phaseReranker:
		b.WriteString(m.renderSelect("7", "Reranker",
			"A cross-encoder re-scores the best candidates before answering. Clearly better on hard and\n"+
				"     multilingual questions (+6 to +9 nDCG@10 on Turkish); ~0.4 s per query with the recommended model.",
			m.rerankOptions, m.rerankOptionIdx,
			[]string{
				"No reranking — faster, uses only embedding + keyword similarity",
				rerankEnableHint(),
			}))

	case phaseRerankFetching:
		b.WriteString(m.renderFetching("Reranker"))

	case phaseRerankModel:
		b.WriteString(m.renderModelSelect("7b", "Reranker Model",
			m.rerankModels, m.rerankModelIdx, m.rerankShowAll,
			len(m.rerankAllModels) != len(m.rerankModels)))

	case phaseIndexDir:
		b.WriteString(m.renderInput("9", "Index Directory", "Absolute path to store vector/graph data", &m.indexDirInput))
	case phaseBackend:
		b.WriteString(m.renderSelect("10", "Vector Backend", "Select the vector indexing engine", m.backendOptions, m.backendOptionIdx, nil))
	case phaseA2A:
		b.WriteString(m.renderSelect("11", "Agent-to-Agent (A2A)", "Enable collaborative multi-agent protocol?", m.a2aOptions, m.a2aOptionIdx, nil))
	case phaseMCP:
		b.WriteString(m.renderSelect("12", "MCP Integration", "Enable Model Context Protocol server?", m.mcpOptions, m.mcpOptionIdx, nil))
	case phaseServer:
		b.WriteString(m.renderServerPhase())
	case phaseServerAddr:
		b.WriteString(m.renderInput("13", "REST API Server Address", "Listen address or port (e.g. :8080, :9090, 127.0.0.1:8080)", &m.serverAddrInput))
	case phaseCustomHFInput:
		b.WriteString(m.renderInput(fmt.Sprintf("%d", m.customHFStepNum()), "Custom HF Model", "Enter HuggingFace ID (e.g. Qwen/Qwen2.5-Coder-1.5B-Instruct-GGUF)", &m.customHFInput))
	case phaseSummary:
		b.WriteString(m.renderSummary())

	case phaseInstall:
		b.WriteString(m.renderSelect("14", "Install / Uninstall",
			"Install gleann to your PATH, or uninstall a previous installation.\n  CLI: gleann install --user | gleann install --system | gleann uninstall [--all]",
			m.installOptions, m.installOptionIdx,
			[]string{
				"Don't install — run from current location",
				"Copy binary + add completions (CLI: gleann install --user)",
				"Copy binary + add completions (requires sudo) (CLI: gleann install --system)",
				"Remove binary from PATH & shell completions (CLI: gleann uninstall)",
				"Remove everything: binary, completions, config & indexes (CLI: gleann uninstall --all)",
			}))
	}

	b.WriteString("\n")
	return tea.NewView(b.String())
}

func (m OnboardModel) renderSettingsMenu() string {
	var b strings.Builder

	b.WriteString(SubtitleStyle.Render("  Select a setting to modify, or save & exit."))
	b.WriteString("\n\n")

	// Compute current values for display.
	values := m.settingsMenuValues()

	labelW := 22
	maxValW := 30
	for i, item := range m.menuItems {
		val := ""
		if i < len(values) {
			val = values[i]
		}
		// Sanitize: no newlines, truncate long values.
		val = strings.ReplaceAll(val, "\n", " ")
		if len(val) > maxValW {
			val = val[:maxValW-3] + "..."
		}

		label := lipgloss.NewStyle().Width(labelW).Render(item.label)
		valStyle := lipgloss.NewStyle().Foreground(ColorMuted)

		if i == m.menuCursor {
			b.WriteString("  " + SelectedDot.String())
			b.WriteString(ActiveItemStyle.Render(label))
			if val != "" {
				b.WriteString(valStyle.Foreground(ColorSecondary).Render(val))
			}
		} else {
			b.WriteString("  " + UnselectedDot.String())
			b.WriteString(NormalItemStyle.Render(label))
			if val != "" {
				b.WriteString(valStyle.Render(val))
			}
		}
		b.WriteString("\n")
	}

	b.WriteString("\n")
	b.WriteString(HelpStyle.Render("  ↑/↓ select • enter edit • esc quit"))
	return b.String()
}

func (m OnboardModel) settingsMenuValues() []string {
	cfg := m.existingCfg
	if cfg == nil {
		cfg = &OnboardResult{}
	}

	embProv := m.embProviders[m.embProviderIdx]
	llmProv := m.llmProviders[m.llmProviderIdx]

	embModel := cfg.EmbeddingModel
	if len(m.embModels) > 0 && m.embModelIdx < len(m.embModels) {
		embModel = m.embModels[m.embModelIdx].Name
	}
	if embModel == "" {
		embModel = "bge-m3"
	}

	llmModel := cfg.LLMModel
	if len(m.llmModels) > 0 && m.llmModelIdx < len(m.llmModels) {
		llmModel = m.llmModels[m.llmModelIdx].Name
	}
	if llmModel == "" {
		llmModel = "nemotron-3-nano:4b"
	}

	host := m.embHostInput.Value()

	// Show host or masked API key depending on provider.
	embHostOrKey := host
	if strings.HasPrefix(embHostOrKey, "http://") && (embProv == "llamacpp" || embProv == "eif" || embProv == "native") {
		embHostOrKey = ""
	}
	if embProv == "openai" {
		k := m.embKeyInput.Value()
		if len(k) > 8 {
			embHostOrKey = k[:4] + "..." + k[len(k)-4:]
		} else if k != "" {
			embHostOrKey = "****"
		}
	} else if embProv == "ollama" && m.ollamaKeyInput.Value() != "" {
		embHostOrKey = "(key) " + embHostOrKey
	} else if embProv == "eif" {
		if embHostOrKey == "" {
			embHostOrKey = "(in-process CGO runtime)"
		}
	} else if embProv == "native" {
		embHostOrKey = "(in-process Candle/Rust)"
	} else if embProv == "llamacpp" {
		if embHostOrKey == "" {
			embHostOrKey = "(auto-scan default dirs)"
		}
	}

	llmHostOrKey := m.llmHostInput.Value()
	if strings.HasPrefix(llmHostOrKey, "http://") && (llmProv == "llamacpp" || llmProv == "eif") {
		llmHostOrKey = ""
	}
	if llmProv == "openai" || llmProv == "anthropic" {
		k := m.llmKeyInput.Value()
		if len(k) > 8 {
			llmHostOrKey = k[:4] + "..." + k[len(k)-4:]
		} else if k != "" {
			llmHostOrKey = "****"
		}
	} else if llmProv == "ollama" && m.ollamaKeyInput.Value() != "" {
		llmHostOrKey = "(key) " + llmHostOrKey
	} else if llmProv == "eif" {
		if llmHostOrKey == "" {
			llmHostOrKey = "(in-process CGO runtime)"
		}
	} else if llmProv == "llamacpp" && llmHostOrKey == "" {
		llmHostOrKey = "(auto-scan default dirs)"
	}

	reranker := "disabled"
	if m.rerankEnabled {
		reranker = "enabled"
	}

	rerankModel := ""
	if m.rerankEnabled {
		if len(m.rerankModels) > 0 && m.rerankModelIdx < len(m.rerankModels) {
			rerankModel = m.rerankModels[m.rerankModelIdx].Name
		} else if cfg.RerankModel != "" {
			rerankModel = cfg.RerankModel
		} else {
			rerankModel = "(select model)"
		}
	} else {
		rerankModel = "—"
	}

	indexDir := m.indexDirInput.Value()

	mcpStatus := "disabled"
	if m.mcpEnabled {
		mcpStatus = "enabled"
	}

	backend := m.selectedBackend()

	a2aStatus := "disabled"
	if m.a2aEnabled {
		a2aStatus = "enabled"
	}

	serverStatus := "disabled"
	if m.serverEnabled {
		serverStatus = m.serverAddrInput.Value()
	}

	codeModel := m.codeEmbeddingModel
	if codeModel == "" {
		codeModel = "(use primary)"
	}
	docModel := m.docEmbeddingModel
	if docModel == "" {
		docModel = "(use primary)"
	}

	return []string{
		embProv,      // Embedding Provider
		embHostOrKey, // Embedding Host / API Key
		embModel,     // Embedding Model
		codeModel,    // Code Embedding Model
		docModel,     // Docs Embedding Model
		llmProv,      // LLM Provider
		llmHostOrKey, // LLM Host / API Key
		llmModel,     // LLM Model
		reranker,     // Reranker
		rerankModel,  // Reranker Model
		indexDir,     // Index Directory
		backend,      // Vector Backend
		a2aStatus,    // Agent-to-Agent (A2A)
		mcpStatus,    // MCP Server
		serverStatus, // REST API Server
		"",           // Install / Uninstall (no current value)
		"🔌",          // Manage Plugins
		"",           // Save & Exit
	}
}

// visibleStep returns the current "user-visible" step number.
func (m OnboardModel) visibleStep() int {
	switch m.phase {
	case phaseEmbProvider:
		return 1
	case phaseEmbHost, phaseEmbOllamaKey, phaseEmbAPIKey:
		return 2
	case phaseEmbFetching:
		return 2
	case phaseEmbModel:
		return 3
	case phaseCodeEmbModel:
		return 4
	case phaseDocEmbModel:
		return 5
	case phaseLLMProvider:
		return 6
	case phaseLLMHost, phaseLLMOllamaKey, phaseLLMAPIKey:
		return 7
	case phaseLLMFetching:
		return 7
	case phaseLLMModel:
		return 8
	case phaseReranker:
		return 9
	case phaseRerankFetching:
		return 9
	case phaseRerankModel:
		return 10
	case phaseIndexDir:
		return 11
	case phaseBackend:
		return 12
	case phaseA2A:
		return 13
	case phaseMCP:
		return 14
	case phaseServer, phaseServerAddr:
		return 15
	case phaseCustomHFInput:
		return m.customHFStepNum()
	case phaseSummary:
		return 16
	case phaseInstall:
		return 17
	}
	return 1
}

// ── Render helpers ─────────────────────────────────────────────

func (m OnboardModel) renderSelect(num, title, desc string, options []string, cursor int, descriptions []string) string {
	var b strings.Builder
	b.WriteString(LabelStyle.Render(fmt.Sprintf("  %s. %s", num, title)))
	b.WriteString("\n")
	b.WriteString(SubtitleStyle.Render("     " + desc))
	b.WriteString("\n\n")

	for i, opt := range options {
		if i == cursor {
			b.WriteString("  " + SelectedDot.String())
			b.WriteString(ActiveItemStyle.Render(opt))
			if i < len(descriptions) {
				b.WriteString("\n")
				b.WriteString(ActiveDescStyle.Render("    " + descriptions[i]))
			}
		} else {
			b.WriteString("  " + UnselectedDot.String())
			b.WriteString(NormalItemStyle.Render(opt))
		}
		b.WriteString("\n")
	}
	b.WriteString("\n")
	b.WriteString(HelpStyle.Render("  ↑/↓ select • enter confirm • esc back"))
	return b.String()
}

func (m OnboardModel) renderInput(num, title, desc string, input *textinput.Model) string {
	var b strings.Builder
	b.WriteString(LabelStyle.Render(fmt.Sprintf("  %s. %s", num, title)))
	b.WriteString("\n")
	b.WriteString(SubtitleStyle.Render("     " + desc))
	b.WriteString("\n\n")
	b.WriteString(FocusedInputStyle.MarginLeft(2).Render(input.View()))
	b.WriteString("\n\n")
	b.WriteString(HelpStyle.Render("  enter confirm • esc back"))
	return b.String()
}

func (m OnboardModel) renderFetching(kind string) string {
	var b strings.Builder
	b.WriteString(LabelStyle.Render(fmt.Sprintf("  %s Models", kind)))
	b.WriteString("\n\n")
	b.WriteString("  " + m.spinner.View())
	b.WriteString(lipgloss.NewStyle().Foreground(ColorSecondary).Render(
		fmt.Sprintf(" Connecting & fetching available %s models...", strings.ToLower(kind))))
	b.WriteString("\n")
	if m.fetchErr != "" {
		b.WriteString("\n")
		b.WriteString(ErrorBadge.Render("  ✗ " + m.fetchErr))
		b.WriteString("\n")
		b.WriteString(HelpStyle.Render("  Showing fallback defaults"))
	}
	return b.String()
}

func (m OnboardModel) renderModelSelect(num, title string, models []ModelInfo, cursor int, showAll, hasFiltered bool) string {
	var b strings.Builder
	b.WriteString(LabelStyle.Render(fmt.Sprintf("  %s. %s", num, title)))
	b.WriteString("\n")

	if m.fetchErr != "" {
		errorMsg := "     ⚠ Could not list the service's models — pick a suggestion or enter the name under Custom…"
		if strings.Contains(m.fetchErr, ".gguf") {
			errorMsg = "     ⚠ No local .gguf models found — please download one to ~/.gleann/models"
		}
		b.WriteString(lipgloss.NewStyle().Foreground(ColorError).Italic(true).Render(errorMsg))
		b.WriteString("\n")
	} else {
		count := fmt.Sprintf("     %d models found", len(models))
		if hasFiltered && !showAll {
			count += " (filtered, tab to show all)"
		} else if hasFiltered && showAll {
			count += " (all, tab to filter)"
		}
		b.WriteString(SubtitleStyle.Render(count))
		b.WriteString("\n")
	}
	b.WriteString("\n")

	// Show max ~15 models at a time with scrolling.
	maxVisible := 15
	if m.height > 0 {
		maxVisible = m.height - 16
		if maxVisible < 5 {
			maxVisible = 5
		}
	}

	start := 0
	if cursor >= maxVisible {
		start = cursor - maxVisible + 1
	}
	end := start + maxVisible
	if end > len(models) {
		end = len(models)
	}

	if start > 0 {
		b.WriteString(lipgloss.NewStyle().Foreground(ColorMuted).Render("     ↑ more"))
		b.WriteString("\n")
	}

	for i := start; i < end; i++ {
		mdl := models[i]
		name := mdl.Name
		detail := ""
		if mdl.Size != "" {
			detail += " " + lipgloss.NewStyle().Foreground(ColorMuted).Render(mdl.Size)
		}
		if mdl.Tag != "" {
			detail += " " + lipgloss.NewStyle().Foreground(ColorDimFg).Render(mdl.Tag)
		}

		if i == cursor && !(m.onCustom && m.modelInputPhase == m.phase) {
			b.WriteString("  " + SelectedDot.String())
			b.WriteString(ActiveItemStyle.Render(name))
			b.WriteString(detail)
		} else {
			b.WriteString("  " + UnselectedDot.String())
			b.WriteString(NormalItemStyle.Render(name))
			b.WriteString(detail)
		}
		b.WriteString("\n")
	}

	if end < len(models) {
		b.WriteString(lipgloss.NewStyle().Foreground(ColorMuted).Render("     ↓ more"))
		b.WriteString("\n")
	}

	b.WriteString("\n")
	onCustom := m.onCustom && m.modelInputPhase == m.phase
	if onCustom {
		b.WriteString("  " + SelectedDot.String() + ActiveItemStyle.Render("Custom…") + "  " + m.modelInput.View() + "\n")
	} else {
		b.WriteString("  " + UnselectedDot.String() + NormalItemStyle.Render("Custom…") + "\n")
	}
	b.WriteString("\n")
	help := "  ↑/↓ select • enter confirm • esc back"
	if onCustom {
		help = "  type the model name • enter use it • ↑ back to the list • esc back"
	}
	if hasFiltered {
		help += " • tab toggle filter"
	}
	b.WriteString(HelpStyle.Render(help))
	return b.String()
}

func (m OnboardModel) renderSummary() string {
	var b strings.Builder

	// Build the result temporarily to display.
	embModel := "bge-m3"
	if len(m.embModels) > 0 && m.embModelIdx < len(m.embModels) {
		embModel = m.embModels[m.embModelIdx].Name
	}
	llmModel := "nemotron-3-nano:4b"
	if len(m.llmModels) > 0 && m.llmModelIdx < len(m.llmModels) {
		llmModel = m.llmModels[m.llmModelIdx].Name
	}

	b.WriteString(SuccessBadge.Render("  ✓ Configuration Summary"))
	b.WriteString("\n\n")

	type row struct{ label, value string }
	rows := []row{
		{"Embedding Provider", m.embProviders[m.embProviderIdx]},
		{"Embedding Model", embModel},
	}
	if m.codeEmbeddingModel != "" {
		rows = append(rows, row{"Code Embedding", m.codeEmbeddingModel})
	}
	if m.docEmbeddingModel != "" {
		rows = append(rows, row{"Docs Embedding", m.docEmbeddingModel})
	}
	if m.embProviders[m.embProviderIdx] == "ollama" {
		rows = append(rows, row{"Ollama Host", m.embHostInput.Value()})
	} else if m.embProviders[m.embProviderIdx] == "native" {
		rows = append(rows, row{"Native Engine", "Enabled (Rust/Candle)"})
	} else if m.embProviders[m.embProviderIdx] == "eif" {
		rows = append(rows, row{"EIF Engine", "In-Process (C99 SIMD / GGUF)"})
	} else if m.embProviders[m.embProviderIdx] == "llamacpp" {
		rows = append(rows, row{"Llama Engine", "Embedded llama-server"})
	} else {
		mask := m.embKeyInput.Value()
		if len(mask) > 8 {
			mask = mask[:4] + "..." + mask[len(mask)-4:]
		}
		rows = append(rows, row{"API Key", mask})
	}
	rows = append(rows,
		row{"LLM Provider", m.llmProviders[m.llmProviderIdx]},
		row{"LLM Model", llmModel},
	)
	if m.embProviders[m.embProviderIdx] == "ollama" || m.llmProviders[m.llmProviderIdx] == "ollama" {
		ollamaKey := "(none)"
		if k := m.ollamaKeyInput.Value(); k != "" {
			ollamaKey = gleann.MaskSecret(k)
		}
		rows = append(rows, row{"Ollama API Key", ollamaKey})
	}
	if m.rerankEnabled {
		rerankModel := "(no model selected)"
		if len(m.rerankModels) > 0 && m.rerankModelIdx < len(m.rerankModels) {
			rerankModel = m.rerankModels[m.rerankModelIdx].Name
		}
		rows = append(rows, row{"Reranker", rerankModel})
	} else {
		rows = append(rows, row{"Reranker", "disabled"})
	}
	backendNames := []string{"diskann", "hnsw", "faiss", "faiss-hybrid"}
	backendName := "diskann"
	if m.backendOptionIdx < len(backendNames) {
		backendName = backendNames[m.backendOptionIdx]
	}
	rows = append(rows,
		row{"Index Directory", m.indexDirInput.Value()},
		row{"Vector Backend", backendName},
	)
	if m.mcpEnabled {
		rows = append(rows, row{"MCP Server", "enabled"})
	} else {
		rows = append(rows, row{"MCP Server", "disabled"})
	}
	if m.serverEnabled {
		rows = append(rows, row{"REST API Server", m.serverAddrInput.Value()})
	} else {
		rows = append(rows, row{"REST API Server", "disabled"})
	}

	box := BoxStyle.Width(56)
	var lines []string
	for _, r := range rows {
		label := lipgloss.NewStyle().Foreground(ColorAccent).Width(22).Render(r.label)
		value := lipgloss.NewStyle().Foreground(ColorFg).Render(r.value)
		lines = append(lines, fmt.Sprintf("  %s  %s", label, value))
	}

	b.WriteString(box.Render(strings.Join(lines, "\n")))
	b.WriteString("\n\n")
	b.WriteString(HelpStyle.Render("  enter save & continue • esc back"))
	return b.String()
}

// ── Utilities ──────────────────────────────────────────────────

func (m OnboardModel) customHFStepNum() int {
	if m.customHFForWhat == "emb" {
		return 3
	} else if m.customHFForWhat == "llm" {
		return 6
	}
	return 8
}

func (m OnboardModel) renderServerPhase() string {
	return m.renderSelect("13", "REST API Server",
		"Enable the REST API server for programmatic access.\nRun with: gleann serve --addr "+m.serverAddrInput.Value(),
		m.serverOptions, m.serverOptionIdx,
		[]string{
			"Don't enable — you can start manually with 'gleann serve'",
			"Save server preference and default listen address",
		})
}

func (m OnboardModel) handleA2AKeys(key string) (tea.Model, tea.Cmd) {
	switch key {
	case "up", "k", "left", "h":
		if m.a2aOptionIdx > 0 {
			m.a2aOptionIdx--
		}
	case "down", "j", "right", "l":
		if m.a2aOptionIdx < len(m.a2aOptions)-1 {
			m.a2aOptionIdx++
		}
	case "enter":
		m.a2aEnabled = (m.a2aOptionIdx == 1)
		if m.menuMode {
			m.phase = phaseMenu
		} else {
			m.phase = phaseMCP
		}
	}
	return m, nil
}

func (m OnboardModel) selectedBackend() string {
	names := []string{"diskann", "hnsw", "faiss", "faiss-hybrid"}
	if m.backendOptionIdx < len(names) {
		return names[m.backendOptionIdx]
	}
	return "diskann"
}

func (m OnboardModel) installPath() string {
	switch m.installOptionIdx {
	case 1:
		return "~/." + "local/bin"
	case 2:
		return "/usr/" + "local/bin"
	default:
		return ""
	}
}

// capitalize returns s with the first letter upper-cased.
func capitalize(s string) string {
	if s == "" {
		return s
	}
	return strings.ToUpper(s[:1]) + s[1:]
}

func (m OnboardModel) handleEmbModelKeys(key string) (tea.Model, tea.Cmd) {
	switch key {
	case "tab":
		m.embShowAll = !m.embShowAll
		m.embModelIdx = 0
		if m.embShowAll {
			m.embModels = m.embAllModels
		} else {
			m.embModels = filterEmbeddingModels(m.embAllModels)
		}
	case "up", "k":
		if m.embModelIdx > 0 {
			m.embModelIdx--
		}
	case "down", "j":
		if m.embModelIdx < len(m.embModels)-1 {
			m.embModelIdx++
		}
	case "enter":
		if len(m.embModels) > 0 && m.embModels[m.embModelIdx].Tag == "custom" {
			m.customHFForWhat = "emb"
			m.phase = phaseCustomHFInput
			m.customHFInput.Focus()
			return m, textinput.Blink
		}
		if m.menuMode {
			m.phase = phaseMenu
		} else {
			m.syncCodeEmbModelIdx()
			m.phase = phaseCodeEmbModel
		}
	}
	return m, nil
}

func (m OnboardModel) primaryEmbModel() string {
	if len(m.embModels) > 0 && m.embModelIdx < len(m.embModels) {
		if m.embProviders[m.embProviderIdx] == "llamacpp" || m.embProviders[m.embProviderIdx] == "eif" {
			if m.embModels[m.embModelIdx].Tag != "" {
				return m.embModels[m.embModelIdx].Tag
			}
		}
		return m.embModels[m.embModelIdx].Name
	}
	if m.existingCfg != nil && m.existingCfg.EmbeddingModel != "" {
		return m.existingCfg.EmbeddingModel
	}
	return "bge-m3"
}

func (m OnboardModel) codeModelOptions() []ModelInfo {
	primary := m.primaryEmbModel()
	opts := []ModelInfo{
		{Name: fmt.Sprintf("✦ (Use Primary Default: %s)", primary), Tag: "", Size: "default"},
	}
	baseModels := m.embModels
	if len(baseModels) == 0 {
		baseModels = m.embAllModels
	}
	if len(baseModels) == 0 && m.existingCfg != nil && m.existingCfg.EmbeddingModel != "" {
		baseModels = []ModelInfo{{Name: m.existingCfg.EmbeddingModel}}
	}
	for _, mdl := range baseModels {
		if mdl.Tag == "custom" {
			continue
		}
		opts = append(opts, mdl)
	}
	if cur := m.codeEmbeddingModel; cur != "" && !hasModel(opts, cur) {
		opts = append(opts, ModelInfo{Name: cur, Tag: cur, Size: "current"})
	}
	return opts
}

func (m OnboardModel) docModelOptions() []ModelInfo {
	primary := m.primaryEmbModel()
	opts := []ModelInfo{
		{Name: fmt.Sprintf("✦ (Use Primary Default: %s)", primary), Tag: "", Size: "default"},
	}
	baseModels := m.embModels
	if len(baseModels) == 0 {
		baseModels = m.embAllModels
	}
	if len(baseModels) == 0 && m.existingCfg != nil && m.existingCfg.EmbeddingModel != "" {
		baseModels = []ModelInfo{{Name: m.existingCfg.EmbeddingModel}}
	}
	for _, mdl := range baseModels {
		if mdl.Tag == "custom" {
			continue
		}
		opts = append(opts, mdl)
	}
	if cur := m.docEmbeddingModel; cur != "" && !hasModel(opts, cur) {
		opts = append(opts, ModelInfo{Name: cur, Tag: cur, Size: "current"})
	}
	return opts
}

func (m *OnboardModel) syncCodeEmbModelIdx() {
	opts := m.codeModelOptions()
	m.codeEmbModelIdx = 0
	if m.codeEmbeddingModel != "" {
		for i, opt := range opts {
			if opt.Name == m.codeEmbeddingModel || opt.Tag == m.codeEmbeddingModel {
				m.codeEmbModelIdx = i
				break
			}
		}
	}
}

func (m *OnboardModel) syncDocEmbModelIdx() {
	opts := m.docModelOptions()
	m.docEmbModelIdx = 0
	if m.docEmbeddingModel != "" {
		for i, opt := range opts {
			if opt.Name == m.docEmbeddingModel || opt.Tag == m.docEmbeddingModel {
				m.docEmbModelIdx = i
				break
			}
		}
	}
}

func (m OnboardModel) handleCodeEmbModelKeys(key string) (tea.Model, tea.Cmd) {
	opts := m.codeModelOptions()
	switch key {
	case "up", "k":
		if m.codeEmbModelIdx > 0 {
			m.codeEmbModelIdx--
		}
	case "down", "j":
		if m.codeEmbModelIdx < len(opts)-1 {
			m.codeEmbModelIdx++
		}
	case "enter":
		if m.codeEmbModelIdx == 0 {
			m.codeEmbeddingModel = ""
		} else if m.codeEmbModelIdx < len(opts) {
			opt := opts[m.codeEmbModelIdx]
			if (m.embProviders[m.embProviderIdx] == "llamacpp" || m.embProviders[m.embProviderIdx] == "eif") && opt.Tag != "" {
				m.codeEmbeddingModel = opt.Tag
			} else {
				m.codeEmbeddingModel = opt.Name
			}
		}
		if m.menuMode {
			m.phase = phaseMenu
		} else {
			m.syncDocEmbModelIdx()
			m.phase = phaseDocEmbModel
		}
	}
	return m, nil
}

func (m OnboardModel) handleDocEmbModelKeys(key string) (tea.Model, tea.Cmd) {
	opts := m.docModelOptions()
	switch key {
	case "up", "k":
		if m.docEmbModelIdx > 0 {
			m.docEmbModelIdx--
		}
	case "down", "j":
		if m.docEmbModelIdx < len(opts)-1 {
			m.docEmbModelIdx++
		}
	case "enter":
		if m.docEmbModelIdx == 0 {
			m.docEmbeddingModel = ""
		} else if m.docEmbModelIdx < len(opts) {
			opt := opts[m.docEmbModelIdx]
			if (m.embProviders[m.embProviderIdx] == "llamacpp" || m.embProviders[m.embProviderIdx] == "eif") && opt.Tag != "" {
				m.docEmbeddingModel = opt.Tag
			} else {
				m.docEmbeddingModel = opt.Name
			}
		}
		if m.menuMode {
			m.phase = phaseMenu
		} else {
			m.phase = phaseLLMProvider
		}
	}
	return m, nil
}

func (m OnboardModel) handleLLMModelKeys(key string) (tea.Model, tea.Cmd) {
	switch key {
	case "tab":
		m.llmShowAll = !m.llmShowAll
		m.llmModelIdx = 0
		if m.llmShowAll {
			m.llmModels = m.llmAllModels
		} else {
			m.llmModels = filterLLMModels(m.llmAllModels)
		}
	case "up", "k":
		if m.llmModelIdx > 0 {
			m.llmModelIdx--
		}
	case "down", "j":
		if m.llmModelIdx < len(m.llmModels)-1 {
			m.llmModelIdx++
		}
	case "enter":
		if len(m.llmModels) > 0 && m.llmModels[m.llmModelIdx].Tag == "custom" {
			m.customHFForWhat = "llm"
			m.phase = phaseCustomHFInput
			m.customHFInput.Focus()
			return m, textinput.Blink
		}
		if m.menuMode {
			m.phase = phaseMenu
		} else {
			m.phase = phaseReranker
		}
	}
	return m, nil
}

func (m OnboardModel) handleRerankerKeys(key string) (tea.Model, tea.Cmd) {
	switch key {
	case "up", "k":
		if m.rerankOptionIdx > 0 {
			m.rerankOptionIdx--
		}
	case "down", "j":
		if m.rerankOptionIdx < len(m.rerankOptions)-1 {
			m.rerankOptionIdx++
		}
	case "enter":
		if m.rerankOptionIdx == 1 {
			m.rerankEnabled = true
			m.phase = phaseRerankFetching
			return m, m.fetchRerankModels()
		} else {
			m.rerankEnabled = false
			if m.menuMode {
				m.phase = phaseMenu
				return m, nil
			}
			m.indexDirInput.Focus()
			m.phase = phaseIndexDir
			return m, textinput.Blink
		}
	}
	return m, nil
}

func (m OnboardModel) handleRerankModelKeys(key string) (tea.Model, tea.Cmd) {
	switch key {
	case "tab":
		m.rerankShowAll = !m.rerankShowAll
		if m.rerankShowAll {
			m.rerankModels = m.rerankAllModels
		} else {
			m.rerankModels = filterRerankerModels(m.rerankAllModels)
		}
		m.rerankModelIdx = 0
	case "up", "k":
		if m.rerankModelIdx > 0 {
			m.rerankModelIdx--
		}
	case "down", "j":
		if m.rerankModelIdx < len(m.rerankModels)-1 {
			m.rerankModelIdx++
		}
	case "enter":
		if len(m.rerankModels) > 0 && m.rerankModels[m.rerankModelIdx].Tag == "custom" {
			m.customHFForWhat = "reranker"
			m.phase = phaseCustomHFInput
			m.customHFInput.Focus()
			return m, textinput.Blink
		}
		if m.menuMode {
			m.phase = phaseMenu
			return m, nil
		}
		m.indexDirInput.Focus()
		m.phase = phaseIndexDir
		return m, textinput.Blink
	}
	return m, nil
}

func (m OnboardModel) handleBackendKeys(key string) (tea.Model, tea.Cmd) {
	switch key {
	case "up", "k":
		if m.backendOptionIdx > 0 {
			m.backendOptionIdx--
		}
	case "down", "j":
		if m.backendOptionIdx < len(m.backendOptions)-1 {
			m.backendOptionIdx++
		}
	case "enter":
		if m.menuMode {
			m.phase = phaseMenu
			return m, nil
		}
		// If FAISS is not available but selected, prevent advancing.
		selected := m.selectedBackend()
		if (selected == "faiss" || selected == "faiss-hybrid") && !gleann.IsFaissSupported() {
			m.fetchErr = "FAISS is not supported in this build. Use HNSW or DiskANN."
			return m, nil
		}
		m.phase = phaseMCP
		return m, nil
	}
	return m, nil
}

func (m OnboardModel) handleMCPKeys(key string) (tea.Model, tea.Cmd) {
	switch key {
	case "up", "k":
		if m.mcpOptionIdx > 0 {
			m.mcpOptionIdx--
		}
	case "down", "j":
		if m.mcpOptionIdx < len(m.mcpOptions)-1 {
			m.mcpOptionIdx++
		}
	case "enter":
		m.mcpEnabled = m.mcpOptionIdx == 1
		if m.menuMode {
			m.phase = phaseMenu
			return m, nil
		}
		m.phase = phaseServer
		return m, nil
	}
	return m, nil
}

func (m OnboardModel) handleServerKeys(key string) (tea.Model, tea.Cmd) {
	switch key {
	case "up", "k":
		if m.serverOptionIdx > 0 {
			m.serverOptionIdx--
		}
	case "down", "j":
		if m.serverOptionIdx < len(m.serverOptions)-1 {
			m.serverOptionIdx++
		}
	case "enter":
		m.serverEnabled = m.serverOptionIdx == 1
		if m.serverEnabled {
			m.phase = phaseServerAddr
			m.focusActiveInput()
			return m, textinput.Blink
		}
		if m.menuMode {
			m.phase = phaseMenu
			return m, nil
		}
		m.phase = phaseSummary
		return m, nil
	}
	return m, nil
}

func (m OnboardModel) handleServerAddrKeys(key string) (tea.Model, tea.Cmd) {
	switch key {
	case "enter":
		addr := strings.TrimSpace(m.serverAddrInput.Value())
		if addr == "" {
			addr = gleann.DefaultServerAddr
		} else if !strings.Contains(addr, ":") {
			addr = ":" + addr
		}
		m.serverAddrInput.SetValue(addr)
		m.serverEnabled = true
		if m.menuMode {
			m.phase = phaseMenu
			return m, nil
		}
		m.phase = phaseSummary
		return m, nil
	}
	return m, nil
}

func (m OnboardModel) handleInstallKeys(key string) (tea.Model, tea.Cmd) {
	switch key {
	case "up", "k":
		if m.installOptionIdx > 0 {
			m.installOptionIdx--
		}
	case "down", "j":
		if m.installOptionIdx < len(m.installOptions)-1 {
			m.installOptionIdx++
		}
	case "enter":
		if m.menuMode {
			if m.installOptionIdx == 0 {
				m.phase = phaseMenu
				return m, nil
			}
			m.buildResult()
			m.done = true
			return m, tea.Quit
		}
		m.buildResult()
		m.done = true
		return m, tea.Quit
	}
	return m, nil
}

// ── Free-text model entry ─────────────────────────────────────

// isModelSelectPhase reports whether phase shows a model list with the
// free-text "Other model" field.
func isModelSelectPhase(p wizardPhase) bool {
	switch p {
	case phaseEmbModel, phaseCodeEmbModel, phaseDocEmbModel, phaseLLMModel, phaseRerankModel:
		return true
	}
	return false
}

// modelListPos returns the length of the current model list and its cursor.
func (m OnboardModel) modelListPos() (n, cursor int) {
	switch m.phase {
	case phaseEmbModel:
		return len(m.embModels), m.embModelIdx
	case phaseCodeEmbModel:
		return len(m.codeModelOptions()), m.codeEmbModelIdx
	case phaseDocEmbModel:
		return len(m.docModelOptions()), m.docEmbModelIdx
	case phaseLLMModel:
		return len(m.llmModels), m.llmModelIdx
	case phaseRerankModel:
		return len(m.rerankModels), m.rerankModelIdx
	}
	return 0, 0
}

// handleModelInputKey handles the "Custom…" row below a model list. Moving
// down past the last model selects it; while it is selected, typing edits the
// field, up returns to the list and enter uses the typed name. Every other
// key is left to the list (handled=false), which works as before.
func (m OnboardModel) handleModelInputKey(msg tea.KeyPressMsg) (OnboardModel, tea.Cmd, bool) {
	if m.modelInputPhase != m.phase {
		m.modelInput.SetValue("")
		m.modelInput.Blur()
		m.onCustom = false
		m.modelInputPhase = m.phase
	}
	key := msg.String()
	n, cursor := m.modelListPos()
	if !m.onCustom {
		if (key == "down" || key == "j") && cursor >= n-1 {
			m.onCustom = true
			return m, m.modelInput.Focus(), true
		}
		return m, nil, false
	}
	switch key {
	case "up":
		if n > 0 {
			m.onCustom = false
			m.modelInput.Blur()
		}
		return m, nil, true
	case "down":
		return m, nil, true
	case "tab", "shift+tab":
		m.onCustom = false // the filter toggle resets the cursor to the top
		m.modelInput.Blur()
		return m, nil, false
	case "enter":
		typed := strings.TrimSpace(m.modelInput.Value())
		if typed == "" {
			return m, nil, true // nothing to use yet
		}
		m.useTypedModel(typed)
		m.onCustom = false
		m.modelInput.Blur()
		return m, nil, false // the list's own enter confirms the now-selected entry
	}
	var cmd tea.Cmd
	m.modelInput, cmd = m.modelInput.Update(msg)
	return m, cmd, true
}

// useTypedModel makes the typed name the highlighted entry of the current list.
func (m *OnboardModel) useTypedModel(name string) {
	switch m.phase {
	case phaseEmbModel:
		m.embModels, m.embModelIdx = selectModel(m.embModels, name, m.embIsLocal())
		m.embAllModels, _ = selectModel(m.embAllModels, name, m.embIsLocal())
	case phaseLLMModel:
		m.llmModels, m.llmModelIdx = selectModel(m.llmModels, name, m.llmIsLocal())
		m.llmAllModels, _ = selectModel(m.llmAllModels, name, m.llmIsLocal())
	case phaseRerankModel:
		m.rerankModels, m.rerankModelIdx = selectModel(m.rerankModels, name, false)
		m.rerankAllModels, _ = selectModel(m.rerankAllModels, name, false)
	case phaseCodeEmbModel:
		m.codeEmbeddingModel = name
		m.syncCodeEmbModelIdx()
	case phaseDocEmbModel:
		m.docEmbeddingModel = name
		m.syncDocEmbModelIdx()
	}
}

// selectModel returns models with name selected: the matching entry, or a new
// first entry when the list does not have it (a model the service did not
// list, or the fallback defaults). local stores name in Tag too, which local
// providers (eif, llamacpp) save instead of Name.
func selectModel(models []ModelInfo, name string, local bool) ([]ModelInfo, int) {
	if name == "" {
		return models, 0
	}
	for i, mdl := range models {
		if mdl.Name == name || mdl.Tag == name {
			return models, i
		}
	}
	entry := ModelInfo{Name: name, Size: "current"}
	if local {
		entry.Tag = name
	}
	return append([]ModelInfo{entry}, models...), 0
}

func hasModel(models []ModelInfo, name string) bool {
	for _, mdl := range models {
		if mdl.Name == name || mdl.Tag == name {
			return true
		}
	}
	return false
}

func (m OnboardModel) embIsLocal() bool {
	p := m.embProviders[m.embProviderIdx]
	return p == "eif" || p == "llamacpp"
}

func (m OnboardModel) llmIsLocal() bool {
	p := m.llmProviders[m.llmProviderIdx]
	return p == "eif" || p == "llamacpp"
}

// currentEmbModel / currentLLMModel are the saved models when the provider is
// unchanged, so reopening a setting keeps them selected instead of silently
// switching to the first fetched or default entry.
func (m OnboardModel) currentEmbModel() string {
	if m.existingCfg == nil || m.existingCfg.EmbeddingProvider != m.embProviders[m.embProviderIdx] {
		return ""
	}
	return m.existingCfg.EmbeddingModel
}

func (m OnboardModel) currentLLMModel() string {
	if m.existingCfg == nil || m.existingCfg.LLMProvider != m.llmProviders[m.llmProviderIdx] {
		return ""
	}
	return m.existingCfg.LLMModel
}

func (m OnboardModel) currentRerankModel() string {
	if m.existingCfg == nil {
		return ""
	}
	return m.existingCfg.RerankModel
}
