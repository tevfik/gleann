package tui

import (
	"testing"

	tea "charm.land/bubbletea/v2"
)

// ── OnboardModel.Update (covers handleKey for all phases) ──────

func TestOnboardUpdateCtrlC(t *testing.T) {
	m := NewOnboardModel()
	result, cmd := m.Update(tea.KeyPressMsg{Code: 'c', Mod: tea.ModCtrl})
	om := result.(OnboardModel)
	if !om.cancelled {
		t.Error("ctrl+c should cancel")
	}
	if cmd == nil {
		t.Error("should return tea.Quit")
	}
}

func TestOnboardUpdateWindowSize(t *testing.T) {
	m := NewOnboardModel()
	result, _ := m.Update(tea.WindowSizeMsg{Width: 120, Height: 40})
	om := result.(OnboardModel)
	if om.width != 120 || om.height != 40 {
		t.Errorf("size = %dx%d, want 120x40", om.width, om.height)
	}
}

func TestOnboardUpdateEscFromWizard(t *testing.T) {
	m := NewOnboardModel()
	m.phase = phaseEmbProvider
	result, _ := m.Update(tea.KeyPressMsg{Code: tea.KeyEscape})
	om := result.(OnboardModel)
	// Esc from phaseEmbProvider should go back to phaseQuickOrAdv.
	if om.phase != phaseQuickOrAdv {
		t.Errorf("phase = %d, want %d (phaseQuickOrAdv)", om.phase, phaseQuickOrAdv)
	}
}

func TestOnboardUpdateEscFromFirstPhase(t *testing.T) {
	m := NewOnboardModel()
	m.phase = phaseQuickOrAdv
	result, cmd := m.Update(tea.KeyPressMsg{Code: tea.KeyEscape})
	om := result.(OnboardModel)
	if !om.cancelled {
		t.Error("esc from first phase should cancel")
	}
	_ = cmd
}

func TestOnboardUpdateEscMenuMode(t *testing.T) {
	cfg := &OnboardResult{EmbeddingProvider: "ollama", LLMProvider: "ollama"}
	m := NewOnboardModelWithConfig(cfg)
	m.phase = phaseEmbProvider
	result, _ := m.Update(tea.KeyPressMsg{Code: tea.KeyEscape})
	om := result.(OnboardModel)
	// In menu mode, esc from sub-phase should return to menu.
	if om.phase != phaseMenu {
		t.Errorf("phase = %d, want %d (phaseMenu)", om.phase, phaseMenu)
	}
}

func TestOnboardUpdateEscMenuAtMenu(t *testing.T) {
	cfg := &OnboardResult{EmbeddingProvider: "ollama", LLMProvider: "ollama"}
	m := NewOnboardModelWithConfig(cfg)
	result, _ := m.Update(tea.KeyPressMsg{Code: tea.KeyEscape})
	om := result.(OnboardModel)
	if !om.cancelled {
		t.Error("esc at menu should cancel")
	}
}

// ── QuickOrAdv phase navigation ────────────────────────────────

func TestOnboardQuickAdvUpDown(t *testing.T) {
	m := NewOnboardModel()
	m.phase = phaseQuickOrAdv
	m.quickAdvOptionIdx = 0

	// Down.
	result, _ := m.Update(tea.KeyPressMsg{Code: 'j'})
	om := result.(OnboardModel)
	if om.quickAdvOptionIdx != 1 {
		t.Errorf("idx = %d, want 1", om.quickAdvOptionIdx)
	}

	// Up.
	result, _ = om.Update(tea.KeyPressMsg{Code: 'k'})
	om = result.(OnboardModel)
	if om.quickAdvOptionIdx != 0 {
		t.Errorf("idx = %d, want 0", om.quickAdvOptionIdx)
	}
}

func TestOnboardQuickAdvEnterAdvanced(t *testing.T) {
	m := NewOnboardModel()
	m.phase = phaseQuickOrAdv
	m.quickAdvOptionIdx = 1 // Advanced.
	result, _ := m.Update(tea.KeyPressMsg{Code: tea.KeyEnter})
	om := result.(OnboardModel)
	if om.phase != phaseEmbProvider {
		t.Errorf("phase = %d, want %d", om.phase, phaseEmbProvider)
	}
}

// ── EmbProvider phase navigation ───────────────────────────────

func TestOnboardEmbProviderUpDown(t *testing.T) {
	m := NewOnboardModel()
	m.phase = phaseEmbProvider
	result, _ := m.Update(tea.KeyPressMsg{Code: 'j'})
	om := result.(OnboardModel)
	if om.embProviderIdx != 1 {
		t.Errorf("idx = %d, want 1", om.embProviderIdx)
	}
}

func TestOnboardEmbProviderEnterOllama(t *testing.T) {
	m := NewOnboardModel()
	m.phase = phaseEmbProvider
	m.embProviderIdx = 0 // ollama
	result, _ := m.Update(tea.KeyPressMsg{Code: tea.KeyEnter})
	om := result.(OnboardModel)
	if om.phase != phaseEmbHost {
		t.Errorf("phase = %d, want %d", om.phase, phaseEmbHost)
	}
}

func TestOnboardEmbProviderEnterOpenAI(t *testing.T) {
	m := NewOnboardModel()
	m.phase = phaseEmbProvider
	m.embProviderIdx = 1 // openai
	result, _ := m.Update(tea.KeyPressMsg{Code: tea.KeyEnter})
	om := result.(OnboardModel)
	if om.phase != phaseEmbAPIKey {
		t.Errorf("phase = %d, want %d", om.phase, phaseEmbAPIKey)
	}
}

func TestOnboardEmbProviderEnterLlamaCPP(t *testing.T) {
	m := NewOnboardModel()
	m.phase = phaseEmbProvider
	m.embProviderIdx = 2 // llamacpp
	result, _ := m.Update(tea.KeyPressMsg{Code: tea.KeyEnter})
	om := result.(OnboardModel)
	// llamacpp goes to fetch phase.
	if om.phase != phaseEmbFetching {
		t.Errorf("phase = %d, want %d", om.phase, phaseEmbFetching)
	}
}

func TestOnboardEmbProviderEnterMenuMode(t *testing.T) {
	cfg := &OnboardResult{EmbeddingProvider: "ollama", LLMProvider: "ollama"}
	m := NewOnboardModelWithConfig(cfg)
	m.phase = phaseEmbProvider
	result, _ := m.Update(tea.KeyPressMsg{Code: tea.KeyEnter})
	om := result.(OnboardModel)
	// In menu mode, enter returns to menu.
	if om.phase != phaseMenu {
		t.Errorf("phase = %d, want %d (phaseMenu)", om.phase, phaseMenu)
	}
}

// ── LLMProvider phase ──────────────────────────────────────────

func TestOnboardLLMProviderUpDown(t *testing.T) {
	m := NewOnboardModel()
	m.phase = phaseLLMProvider
	result, _ := m.Update(tea.KeyPressMsg{Code: 'j'})
	om := result.(OnboardModel)
	if om.llmProviderIdx != 1 {
		t.Errorf("idx = %d, want 1", om.llmProviderIdx)
	}
}

func TestOnboardLLMProviderEnterOllama(t *testing.T) {
	m := NewOnboardModel()
	m.phase = phaseLLMProvider
	m.llmProviderIdx = 0 // ollama (same as emb default)
	// Same provider as emb → skip to fetch.
	result, _ := m.Update(tea.KeyPressMsg{Code: tea.KeyEnter})
	om := result.(OnboardModel)
	if om.phase != phaseLLMFetching {
		t.Errorf("phase = %d, want %d (phaseLLMFetching)", om.phase, phaseLLMFetching)
	}
}

func TestOnboardLLMProviderEnterDifferent(t *testing.T) {
	m := NewOnboardModel()
	m.phase = phaseLLMProvider
	m.llmProviderIdx = 1 // openai (different from emb ollama)
	result, _ := m.Update(tea.KeyPressMsg{Code: tea.KeyEnter})
	om := result.(OnboardModel)
	if om.phase != phaseLLMAPIKey {
		t.Errorf("phase = %d, want %d (phaseLLMAPIKey)", om.phase, phaseLLMAPIKey)
	}
}

func TestOnboardLLMProviderEnterLlamaCPP(t *testing.T) {
	m := NewOnboardModel()
	m.phase = phaseLLMProvider
	m.llmProviderIdx = 3 // llamacpp (different from emb ollama)
	result, _ := m.Update(tea.KeyPressMsg{Code: tea.KeyEnter})
	om := result.(OnboardModel)
	if om.phase != phaseLLMFetching {
		t.Errorf("phase = %d, want %d", om.phase, phaseLLMFetching)
	}
}

// ── Text input phases ──────────────────────────────────────────

func TestOnboardEmbHostEnter(t *testing.T) {
	m := NewOnboardModel()
	m.phase = phaseEmbHost
	result, _ := m.Update(tea.KeyPressMsg{Code: tea.KeyEnter})
	om := result.(OnboardModel)
	// Ollama host is followed by the optional API key step.
	if om.phase != phaseEmbOllamaKey {
		t.Errorf("phase = %d, want %d (phaseEmbOllamaKey)", om.phase, phaseEmbOllamaKey)
	}
	result, _ = om.Update(tea.KeyPressMsg{Code: tea.KeyEnter})
	om = result.(OnboardModel)
	if om.phase != phaseEmbFetching {
		t.Errorf("phase = %d, want %d", om.phase, phaseEmbFetching)
	}
}

func TestOnboardEmbAPIKeyEnter(t *testing.T) {
	m := NewOnboardModel()
	m.phase = phaseEmbAPIKey
	result, _ := m.Update(tea.KeyPressMsg{Code: tea.KeyEnter})
	om := result.(OnboardModel)
	if om.phase != phaseEmbFetching {
		t.Errorf("phase = %d, want %d", om.phase, phaseEmbFetching)
	}
}

func TestOnboardLLMHostEnter(t *testing.T) {
	m := NewOnboardModel()
	m.phase = phaseLLMHost
	result, _ := m.Update(tea.KeyPressMsg{Code: tea.KeyEnter})
	om := result.(OnboardModel)
	// Ollama host is followed by the optional API key step.
	if om.phase != phaseLLMOllamaKey {
		t.Errorf("phase = %d, want %d (phaseLLMOllamaKey)", om.phase, phaseLLMOllamaKey)
	}
	result, _ = om.Update(tea.KeyPressMsg{Code: tea.KeyEnter})
	om = result.(OnboardModel)
	if om.phase != phaseLLMFetching {
		t.Errorf("phase = %d, want %d", om.phase, phaseLLMFetching)
	}
}

func TestOnboardLLMAPIKeyEnter(t *testing.T) {
	m := NewOnboardModel()
	m.phase = phaseLLMAPIKey
	result, _ := m.Update(tea.KeyPressMsg{Code: tea.KeyEnter})
	om := result.(OnboardModel)
	if om.phase != phaseLLMFetching {
		t.Errorf("phase = %d, want %d", om.phase, phaseLLMFetching)
	}
}

func TestOnboardIndexDirEnter(t *testing.T) {
	m := NewOnboardModel()
	m.phase = phaseIndexDir
	result, _ := m.Update(tea.KeyPressMsg{Code: tea.KeyEnter})
	om := result.(OnboardModel)
	if om.phase != phaseBackend {
		t.Errorf("phase = %d, want %d", om.phase, phaseBackend)
	}
}

// ── Model select phases ────────────────────────────────────────

func TestOnboardEmbModelUpDownEnter(t *testing.T) {
	m := NewOnboardModel()
	m.phase = phaseEmbModel
	m.embModels = []ModelInfo{{Name: "a"}, {Name: "b"}}
	m.embAllModels = m.embModels

	result, _ := m.Update(tea.KeyPressMsg{Code: 'j'})
	om := result.(OnboardModel)
	if om.embModelIdx != 1 {
		t.Errorf("idx = %d, want 1", om.embModelIdx)
	}

	result, _ = om.Update(tea.KeyPressMsg{Code: tea.KeyEnter})
	om = result.(OnboardModel)
	if om.phase != phaseCodeEmbModel {
		t.Errorf("phase = %d, want %d", om.phase, phaseCodeEmbModel)
	}
}

func TestOnboardEmbModelTab(t *testing.T) {
	m := NewOnboardModel()
	m.phase = phaseEmbModel
	m.embModels = []ModelInfo{{Name: "a"}}
	m.embAllModels = []ModelInfo{{Name: "a"}, {Name: "b"}, {Name: "c"}}

	result, _ := m.Update(tea.KeyPressMsg{Code: tea.KeyTab})
	om := result.(OnboardModel)
	if !om.embShowAll {
		t.Error("tab should toggle showAll")
	}
	if len(om.embModels) != 3 {
		t.Errorf("should show all %d models", len(m.embAllModels))
	}
}

func TestOnboardLLMModelUpDownEnter(t *testing.T) {
	m := NewOnboardModel()
	m.phase = phaseLLMModel
	m.llmModels = []ModelInfo{{Name: "a"}, {Name: "b"}}
	m.llmAllModels = m.llmModels

	result, _ := m.Update(tea.KeyPressMsg{Code: 'j'})
	om := result.(OnboardModel)
	if om.llmModelIdx != 1 {
		t.Errorf("idx = %d", om.llmModelIdx)
	}

	result, _ = om.Update(tea.KeyPressMsg{Code: tea.KeyEnter})
	om = result.(OnboardModel)
	if om.phase != phaseReranker {
		t.Errorf("phase = %d, want %d", om.phase, phaseReranker)
	}
}

func TestOnboardLLMModelTab(t *testing.T) {
	m := NewOnboardModel()
	m.phase = phaseLLMModel
	m.llmModels = []ModelInfo{{Name: "a"}}
	m.llmAllModels = []ModelInfo{{Name: "a"}, {Name: "b"}}

	result, _ := m.Update(tea.KeyPressMsg{Code: tea.KeyTab})
	om := result.(OnboardModel)
	if !om.llmShowAll {
		t.Error("tab should toggle showAll")
	}
}

// ── Reranker toggle ────────────────────────────────────────────

func TestOnboardRerankerDisable(t *testing.T) {
	m := NewOnboardModel()
	m.phase = phaseReranker
	m.rerankOptionIdx = 0 // Skip
	result, _ := m.Update(tea.KeyPressMsg{Code: tea.KeyEnter})
	om := result.(OnboardModel)
	if om.rerankEnabled {
		t.Error("should not enable reranker")
	}
	if om.phase != phaseIndexDir {
		t.Errorf("phase = %d, want %d", om.phase, phaseIndexDir)
	}
}

func TestOnboardRerankerEnable(t *testing.T) {
	m := NewOnboardModel()
	m.phase = phaseReranker
	m.rerankOptionIdx = 1 // Enable
	result, _ := m.Update(tea.KeyPressMsg{Code: tea.KeyEnter})
	om := result.(OnboardModel)
	if !om.rerankEnabled {
		t.Error("should enable reranker")
	}
	if om.phase != phaseRerankFetching {
		t.Errorf("phase = %d, want %d", om.phase, phaseRerankFetching)
	}
}

func TestOnboardRerankerUpDown(t *testing.T) {
	m := NewOnboardModel()
	m.phase = phaseReranker
	result, _ := m.Update(tea.KeyPressMsg{Code: 'j'})
	om := result.(OnboardModel)
	if om.rerankOptionIdx != 1 {
		t.Errorf("idx = %d, want 1", om.rerankOptionIdx)
	}
}

// ── RerankerModel ──────────────────────────────────────────────

func TestOnboardRerankModelUpDown(t *testing.T) {
	m := NewOnboardModel()
	m.phase = phaseRerankModel
	m.rerankModels = []ModelInfo{{Name: "a"}, {Name: "b"}}
	m.rerankAllModels = m.rerankModels
	result, _ := m.Update(tea.KeyPressMsg{Code: 'j'})
	om := result.(OnboardModel)
	if om.rerankModelIdx != 1 {
		t.Errorf("idx = %d", om.rerankModelIdx)
	}
}

func TestOnboardRerankModelTab(t *testing.T) {
	m := NewOnboardModel()
	m.phase = phaseRerankModel
	m.rerankModels = []ModelInfo{{Name: "a"}}
	m.rerankAllModels = []ModelInfo{{Name: "a"}, {Name: "b"}}
	result, _ := m.Update(tea.KeyPressMsg{Code: tea.KeyTab})
	om := result.(OnboardModel)
	if !om.rerankShowAll {
		t.Error("tab should toggle showAll")
	}
}

func TestOnboardRerankModelEnter(t *testing.T) {
	m := NewOnboardModel()
	m.phase = phaseRerankModel
	m.rerankModels = []ModelInfo{{Name: "a"}}
	result, _ := m.Update(tea.KeyPressMsg{Code: tea.KeyEnter})
	om := result.(OnboardModel)
	if om.phase != phaseIndexDir {
		t.Errorf("phase = %d, want phaseIndexDir", om.phase)
	}
}

// ── MCP toggle ─────────────────────────────────────────────────

func TestOnboardMCPUpDownEnter(t *testing.T) {
	m := NewOnboardModel()
	m.phase = phaseMCP
	result, _ := m.Update(tea.KeyPressMsg{Code: 'j'})
	om := result.(OnboardModel)
	if om.mcpOptionIdx != 1 {
		t.Errorf("idx = %d", om.mcpOptionIdx)
	}

	result, _ = om.Update(tea.KeyPressMsg{Code: tea.KeyEnter})
	om = result.(OnboardModel)
	if !om.mcpEnabled {
		t.Error("should be enabled")
	}
	if om.phase != phaseServer {
		t.Errorf("phase = %d, want phaseServer", om.phase)
	}
}

// ── Server toggle ───────────────────────────────────────────────

func TestOnboardServerUpDownEnter(t *testing.T) {
	m := NewOnboardModel()
	m.phase = phaseServer
	result, _ := m.Update(tea.KeyPressMsg{Code: 'j'})
	om := result.(OnboardModel)
	if om.serverOptionIdx != 1 {
		t.Errorf("idx = %d", om.serverOptionIdx)
	}

	result, _ = om.Update(tea.KeyPressMsg{Code: tea.KeyEnter})
	om = result.(OnboardModel)
	if !om.serverEnabled {
		t.Error("should be enabled")
	}
	if om.phase != phaseServerAddr {
		t.Errorf("phase = %d, want phaseServerAddr", om.phase)
	}

	result, _ = om.Update(tea.KeyPressMsg{Code: tea.KeyEnter})
	om = result.(OnboardModel)
	if om.phase != phaseSummary {
		t.Errorf("phase = %d, want phaseSummary", om.phase)
	}
}

// ── Summary → Install ──────────────────────────────────────────

func TestOnboardSummaryEnter(t *testing.T) {
	m := NewOnboardModel()
	m.phase = phaseSummary
	result, _ := m.Update(tea.KeyPressMsg{Code: tea.KeyEnter})
	om := result.(OnboardModel)
	if om.phase != phaseInstall {
		t.Errorf("phase = %d, want phaseInstall", om.phase)
	}
}

// ── Install phase ──────────────────────────────────────────────

func TestOnboardInstallUpDown(t *testing.T) {
	m := NewOnboardModel()
	m.phase = phaseInstall
	result, _ := m.Update(tea.KeyPressMsg{Code: 'j'})
	om := result.(OnboardModel)
	if om.installOptionIdx != 1 {
		t.Errorf("idx = %d", om.installOptionIdx)
	}
}

func TestOnboardInstallEnter(t *testing.T) {
	m := NewOnboardModel()
	m.phase = phaseInstall
	result, cmd := m.Update(tea.KeyPressMsg{Code: tea.KeyEnter})
	om := result.(OnboardModel)
	if !om.done {
		t.Error("should be done")
	}
	_ = cmd
}

// ── Menu navigation ────────────────────────────────────────────

func TestOnboardMenuUpDown(t *testing.T) {
	cfg := &OnboardResult{EmbeddingProvider: "ollama", LLMProvider: "ollama"}
	m := NewOnboardModelWithConfig(cfg)
	result, _ := m.Update(tea.KeyPressMsg{Code: 'j'})
	om := result.(OnboardModel)
	if om.menuCursor != 1 {
		t.Errorf("cursor = %d, want 1", om.menuCursor)
	}
	result, _ = om.Update(tea.KeyPressMsg{Code: 'k'})
	om = result.(OnboardModel)
	if om.menuCursor != 0 {
		t.Errorf("cursor = %d, want 0", om.menuCursor)
	}
}

func TestOnboardMenuSaveAndExit(t *testing.T) {
	cfg := &OnboardResult{EmbeddingProvider: "ollama", LLMProvider: "ollama"}
	m := NewOnboardModelWithConfig(cfg)
	// Navigate to "Save & Exit" (last item).
	m.menuCursor = len(m.menuItems) - 1
	result, _ := m.Update(tea.KeyPressMsg{Code: tea.KeyEnter})
	om := result.(OnboardModel)
	if !om.done {
		t.Error("should be done after Save & Exit")
	}
}

func TestOnboardMenuEnterSubPhase(t *testing.T) {
	cfg := &OnboardResult{EmbeddingProvider: "ollama", LLMProvider: "ollama"}
	m := NewOnboardModelWithConfig(cfg)
	m.menuCursor = 1 // Embedding Provider (0 is All Settings)
	result, _ := m.Update(tea.KeyPressMsg{Code: tea.KeyEnter})
	om := result.(OnboardModel)
	if om.phase != phaseEmbProvider {
		t.Errorf("phase = %d, want %d", om.phase, phaseEmbProvider)
	}
}

func TestOnboardMenuOpensAllSettings(t *testing.T) {
	m := NewOnboardModelWithConfig(&OnboardResult{EmbeddingProvider: "ollama", LLMProvider: "ollama"})
	if m.menuItems[0].phase != phaseSettingsScreen {
		t.Fatalf("All Settings must be the first menu item, got %q", m.menuItems[0].label)
	}
	result, _ := m.Update(tea.KeyPressMsg{Code: tea.KeyEnter})
	om := result.(OnboardModel)
	if !om.OpenSettings() || om.OpenPlugins() || om.Result().Completed {
		t.Fatal("All Settings opens the settings screen and saves nothing itself")
	}
}

// ── modelsFetchedMsg handling ──────────────────────────────────

func TestOnboardUpdateModelsFetched(t *testing.T) {
	m := NewOnboardModel()
	m.phase = phaseEmbFetching
	result, _ := m.Update(modelsFetchedMsg{
		models: []ModelInfo{{Name: "bge-m3"}, {Name: "nomic"}},
		err:    nil,
	})
	om := result.(OnboardModel)
	if om.phase != phaseEmbModel {
		t.Errorf("phase = %d, want phaseEmbModel", om.phase)
	}
	if len(om.embAllModels) != 2 {
		t.Errorf("models = %d, want 2", len(om.embAllModels))
	}
}

func TestOnboardUpdateModelsFetchedError(t *testing.T) {
	m := NewOnboardModel()
	m.phase = phaseEmbFetching
	result, _ := m.Update(modelsFetchedMsg{
		err: &testError{msg: "connection refused"},
	})
	om := result.(OnboardModel)
	if om.fetchErr == "" {
		t.Error("fetchErr should be set")
	}
	if om.phase != phaseEmbModel {
		t.Errorf("phase = %d, want phaseEmbModel (fallback)", om.phase)
	}
}

func TestOnboardUpdateLLMModelsFetched(t *testing.T) {
	m := NewOnboardModel()
	m.phase = phaseLLMFetching
	result, _ := m.Update(modelsFetchedMsg{
		models: []ModelInfo{{Name: "llama3"}, {Name: "gpt-4o"}},
		forLLM: true,
	})
	om := result.(OnboardModel)
	if om.phase != phaseLLMModel {
		t.Errorf("phase = %d, want phaseLLMModel", om.phase)
	}
}

func TestOnboardUpdateLLMModelsFetchedError(t *testing.T) {
	m := NewOnboardModel()
	m.phase = phaseLLMFetching
	result, _ := m.Update(modelsFetchedMsg{
		forLLM: true,
		err:    &testError{msg: "timeout"},
	})
	om := result.(OnboardModel)
	if om.phase != phaseLLMModel {
		t.Errorf("phase = %d", om.phase)
	}
}

func TestOnboardUpdateRerankModelsFetched(t *testing.T) {
	m := NewOnboardModel()
	m.phase = phaseRerankFetching
	result, _ := m.Update(modelsFetchedMsg{
		models:      []ModelInfo{{Name: "bge-reranker-v2-m3"}, {Name: "other-model"}},
		forReranker: true,
	})
	om := result.(OnboardModel)
	if om.phase != phaseRerankModel {
		t.Errorf("phase = %d, want phaseRerankModel", om.phase)
	}
}

func TestOnboardUpdateRerankModelsFetchedError(t *testing.T) {
	m := NewOnboardModel()
	m.phase = phaseRerankFetching
	result, _ := m.Update(modelsFetchedMsg{
		forReranker: true,
		err:         &testError{msg: "no models"},
	})
	om := result.(OnboardModel)
	// The list could not be fetched: suggestions plus the Custom row, not a
	// silent switch-off (esc still goes back to the on/off choice).
	if om.phase != phaseRerankModel {
		t.Errorf("phase = %d, want phaseRerankModel", om.phase)
	}
	if len(om.rerankModels) == 0 || om.fetchErr == "" {
		t.Errorf("want suggestions and an error note, got %+v / %q", om.rerankModels, om.fetchErr)
	}
}

// ── Menu mode sub-phase enter → back to menu ───────────────────

func TestOnboardMenuEmbHostEnterReturnsToMenu(t *testing.T) {
	cfg := &OnboardResult{EmbeddingProvider: "ollama", LLMProvider: "ollama"}
	m := NewOnboardModelWithConfig(cfg)
	m.phase = phaseEmbHost
	result, _ := m.Update(tea.KeyPressMsg{Code: tea.KeyEnter})
	om := result.(OnboardModel)
	// In menu mode, an Ollama host goes to the optional key step first,
	// then back to the menu.
	if om.phase != phaseEmbOllamaKey {
		t.Fatalf("phase = %d, want phaseEmbOllamaKey", om.phase)
	}
	result, _ = om.Update(tea.KeyPressMsg{Code: tea.KeyEnter})
	om = result.(OnboardModel)
	if om.phase != phaseMenu {
		t.Errorf("phase = %d, want phaseMenu", om.phase)
	}
}

func TestOnboardMenuMCPEnterReturnsToMenu(t *testing.T) {
	cfg := &OnboardResult{EmbeddingProvider: "ollama", LLMProvider: "ollama"}
	m := NewOnboardModelWithConfig(cfg)
	m.phase = phaseMCP
	result, _ := m.Update(tea.KeyPressMsg{Code: tea.KeyEnter})
	om := result.(OnboardModel)
	if om.phase != phaseMenu {
		t.Errorf("phase = %d, want phaseMenu", om.phase)
	}
}

func TestOnboardMenuServerEnterReturnsToMenu(t *testing.T) {
	cfg := &OnboardResult{EmbeddingProvider: "ollama", LLMProvider: "ollama"}
	m := NewOnboardModelWithConfig(cfg)
	m.phase = phaseServer
	result, _ := m.Update(tea.KeyPressMsg{Code: tea.KeyEnter})
	om := result.(OnboardModel)
	if om.phase != phaseMenu {
		t.Errorf("phase = %d, want phaseMenu", om.phase)
	}
}

func TestOnboardMenuRerankDisableReturnsToMenu(t *testing.T) {
	cfg := &OnboardResult{EmbeddingProvider: "ollama", LLMProvider: "ollama"}
	m := NewOnboardModelWithConfig(cfg)
	m.phase = phaseReranker
	m.rerankOptionIdx = 0 // Skip
	result, _ := m.Update(tea.KeyPressMsg{Code: tea.KeyEnter})
	om := result.(OnboardModel)
	if om.phase != phaseMenu {
		t.Errorf("phase = %d, want phaseMenu", om.phase)
	}
}

// testError implements error interface for testing.
type testError struct {
	msg string
}

func (e *testError) Error() string { return e.msg }

func TestOnboardCodeAndDocEmbModelFlow(t *testing.T) {
	m := NewOnboardModel()
	m.embModels = []ModelInfo{{Name: "bge-m3"}, {Name: "all-minilm"}}
	m.embAllModels = m.embModels

	// Enter on primary embedding model goes to code embedding model
	m.phase = phaseEmbModel
	res, _ := m.Update(tea.KeyPressMsg{Code: tea.KeyEnter})
	om := res.(OnboardModel)
	if om.phase != phaseCodeEmbModel {
		t.Fatalf("expected phaseCodeEmbModel, got %v", om.phase)
	}

	// Navigate to item 2 (all-minilm) and press Enter -> goes to phaseDocEmbModel
	res, _ = om.Update(tea.KeyPressMsg{Code: 'j'})
	om = res.(OnboardModel)
	res, _ = om.Update(tea.KeyPressMsg{Code: 'j'})
	om = res.(OnboardModel)
	res, _ = om.Update(tea.KeyPressMsg{Code: tea.KeyEnter})
	om = res.(OnboardModel)
	if om.phase != phaseDocEmbModel {
		t.Fatalf("expected phaseDocEmbModel, got %v", om.phase)
	}
	if om.codeEmbeddingModel != "all-minilm" {
		t.Errorf("expected codeEmbeddingModel all-minilm, got %q", om.codeEmbeddingModel)
	}

	// Press Enter on item 0 (default) in doc model -> goes to phaseLLMProvider
	res, _ = om.Update(tea.KeyPressMsg{Code: tea.KeyEnter})
	om = res.(OnboardModel)
	if om.phase != phaseLLMProvider {
		t.Fatalf("expected phaseLLMProvider, got %v", om.phase)
	}
	if om.docEmbeddingModel != "" {
		t.Errorf("expected docEmbeddingModel empty (default), got %q", om.docEmbeddingModel)
	}

	om.buildResult()
	if om.result.CodeEmbeddingModel != "all-minilm" {
		t.Errorf("result code model mismatch: %q", om.result.CodeEmbeddingModel)
	}
	if om.result.DocEmbeddingModel != "" {
		t.Errorf("result doc model mismatch: %q", om.result.DocEmbeddingModel)
	}
}

func TestOnboardCodeAndDocEmbModelMenu(t *testing.T) {
	cfg := &OnboardResult{EmbeddingProvider: "ollama", LLMProvider: "ollama", EmbeddingModel: "bge-m3"}
	m := NewOnboardModelWithConfig(cfg)
	m.embModels = []ModelInfo{{Name: "bge-m3"}, {Name: "code-bert"}}
	m.embAllModels = m.embModels

	m.phase = phaseCodeEmbModel
	res, _ := m.Update(tea.KeyPressMsg{Code: 'j'})
	om := res.(OnboardModel)
	res, _ = om.Update(tea.KeyPressMsg{Code: 'j'})
	om = res.(OnboardModel)
	res, _ = om.Update(tea.KeyPressMsg{Code: tea.KeyEnter})
	om = res.(OnboardModel)
	if om.phase != phaseMenu {
		t.Fatalf("expected phaseMenu, got %v", om.phase)
	}
	if om.codeEmbeddingModel != "code-bert" {
		t.Errorf("expected code-bert, got %q", om.codeEmbeddingModel)
	}
}

func TestOnboardMenuInstallOptionZeroReturnsToMenu(t *testing.T) {
	cfg := &OnboardResult{EmbeddingProvider: "ollama", LLMProvider: "ollama"}
	m := NewOnboardModelWithConfig(cfg)
	m.phase = phaseInstall
	m.installOptionIdx = 0 // "Don't install"

	res, cmd := m.Update(tea.KeyPressMsg{Code: tea.KeyEnter})
	om := res.(OnboardModel)
	if om.done {
		t.Error("expected om.done to be false when selecting 'Don't install' from menu")
	}
	if om.phase != phaseMenu {
		t.Errorf("expected phaseMenu, got %v", om.phase)
	}
	if cmd != nil {
		t.Error("expected no quit command on option 0 in menuMode")
	}
}

func TestOnboardMenuServerAddrFlow(t *testing.T) {
	cfg := &OnboardResult{EmbeddingProvider: "ollama", LLMProvider: "ollama"}
	m := NewOnboardModelWithConfig(cfg)
	m.phase = phaseServer
	m.serverOptionIdx = 1 // Enable server

	res, _ := m.Update(tea.KeyPressMsg{Code: tea.KeyEnter})
	om := res.(OnboardModel)
	if om.phase != phaseServerAddr {
		t.Fatalf("expected phaseServerAddr, got %v", om.phase)
	}

	om.serverAddrInput.SetValue("9090")
	res, _ = om.Update(tea.KeyPressMsg{Code: tea.KeyEnter})
	om = res.(OnboardModel)
	if om.phase != phaseMenu {
		t.Errorf("expected phaseMenu, got %v", om.phase)
	}
	if om.serverAddrInput.Value() != ":9090" {
		t.Errorf("expected :9090, got %q", om.serverAddrInput.Value())
	}
	if !om.serverEnabled {
		t.Error("expected serverEnabled to be true")
	}
}
